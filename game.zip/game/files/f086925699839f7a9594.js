function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * コンバータ機能を提供するクラス。
       */

      var Converter =
      /** @class */
      function () {
        function Converter() {}
        /**
         * エンティティをホバー可能に変換する。
         */


        Converter.asHoverable = function (e, opts) {
          var hoverableE = e;
          hoverableE.hoverable = true;
          hoverableE.touchable = true;
          hoverableE.hovered = hoverableE.hovered || new g.Trigger();
          hoverableE.unhovered = hoverableE.unhovered || new g.Trigger();

          if (opts) {
            if (opts.cursor) hoverableE.cursor = opts.cursor;
          }

          return hoverableE;
        };
        /**
         * エンティティのホバーを解除する。
         */


        Converter.asUnhoverable = function (e) {
          var hoverableE = e;
          delete hoverableE.hoverable;

          if (hoverableE.hovered && !hoverableE.hovered.destroyed()) {
            hoverableE.hovered.destroy();
            delete hoverableE.hovered;
          }

          if (hoverableE.unhovered && !hoverableE.unhovered.destroyed()) {
            hoverableE.unhovered.fire();
            hoverableE.unhovered.destroy();
            delete hoverableE.unhovered;
          }

          return hoverableE;
        };

        return Converter;
      }();

      exports.Converter = Converter;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * ホバー機能を提供するプラグイン。
       */

      var HoverPlugin =
      /** @class */
      function () {
        function HoverPlugin(game, view, option) {
          if (option === void 0) {
            option = {};
          }

          this.game = game;
          this.view = view.view;
          this.beforeHover = null;
          this.operationTrigger = new g.Trigger();
          this._cursor = option.cursor || "pointer";
          this._showTooltip = !!option.showTooltip;
          this._getScale = view.getScale ? function () {
            return view.getScale();
          } : null;
          this._onMouseMove_bound = this._onMouseMove.bind(this);
          this._onMouseOut_bound = this._onMouseOut.bind(this);
        }

        HoverPlugin.isSupported = function () {
          return typeof document !== "undefined" && typeof document.addEventListener === "function";
        };

        HoverPlugin.prototype.start = function () {
          this.view.addEventListener("mousemove", this._onMouseMove_bound, false);
          this.view.addEventListener("mouseout", this._onMouseOut_bound, false);
          return true;
        };

        HoverPlugin.prototype.stop = function () {
          this.view.removeEventListener("mousemove", this._onMouseMove_bound, false);
          this.view.removeEventListener("mouseout", this._onMouseOut_bound, false);
        };

        HoverPlugin.prototype._onMouseMove = function (e) {
          var scene = this.game.scene();
          if (!scene) return;
          var rect = this.view.getBoundingClientRect();
          var positionX = rect.left + window.pageXOffset;
          var positionY = rect.top + window.pageYOffset;
          var offsetX = e.pageX - positionX;
          var offsetY = e.pageY - positionY;
          var scale = {
            x: 1,
            y: 1
          };

          if (this._getScale) {
            scale = this._getScale();
          }

          var point = {
            x: offsetX / scale.x,
            y: offsetY / scale.y
          };
          var target = scene.findPointSourceByPoint(point).target;

          if (target && target.hoverable) {
            if (target !== this.beforeHover) {
              if (this.beforeHover && this.beforeHover.hoverable) {
                this._onUnhovered(target);
              }

              this._onHovered(target);
            }

            this.beforeHover = target;
          } else if (this.beforeHover) {
            this._onUnhovered(this.beforeHover);
          }
        };

        HoverPlugin.prototype._onHovered = function (target) {
          if (target.hoverable) {
            this.view.style.cursor = target.cursor ? target.cursor : this._cursor;

            if (this._showTooltip && target.title) {
              this.view.setAttribute("title", target.title);
            }

            target.hovered.fire();
          }
        };

        HoverPlugin.prototype._onUnhovered = function (target) {
          this.view.style.cursor = "auto";

          if (this.beforeHover && this.beforeHover.unhovered) {
            this.beforeHover.unhovered.fire();

            if (this._showTooltip) {
              this.view.removeAttribute("title");
            }
          }

          this.beforeHover = null;
        };

        HoverPlugin.prototype._onMouseOut = function () {
          if (this.beforeHover) this._onUnhovered(this.beforeHover);
        };

        return HoverPlugin;
      }();

      exports.HoverPlugin = HoverPlugin;
      module.exports = HoverPlugin;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Converter_1 = require("./Converter");

      exports.Converter = Converter_1.Converter;
    }, {
      "./Converter": 1
    }],
    4: [function (require, module, exports) {
      "use strict";

      var __assign = this && this.__assign || function () {
        __assign = Object.assign || function (t) {
          for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];

            for (var p in s) {
              if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
          }

          return t;
        };

        return __assign.apply(this, arguments);
      };

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.FallbackDialog = void 0;

      var akashic_hover_plugin_1 = require("@akashic-extension/akashic-hover-plugin");

      var HoverPluginRaw = require("@akashic-extension/akashic-hover-plugin/lib/HoverPlugin"); // Ugh! HoverPlugin が Akashic Engine 向けに中途半端に CommonJS で (module.exports = HoverPlugin と)
      // 定義されている関係で、 import すると TS の型と実体が合わない。無理やり解消する。
      // (import * as ... すると、 JS 的には HoverPlugin の実体が手に入るが、TS 上では namespace と誤認される)
      // さらにおそらく akashic-hover-plugin 側のバグで、型があっていないのでそれも無理やり合わせる。
      // (コンストラクタ第二引数が間違っている。実装上は any キャストして正しく使っている)


      var HoverPlugin = HoverPluginRaw;

      function drawCircle(rendr, centerX, centerY, radius, cssColor) {
        for (var y = centerY - radius | 0; y <= Math.ceil(centerY + radius); ++y) {
          var w = radius * Math.cos(Math.asin((centerY - y) / radius));
          rendr.fillRect(centerX - w, y, 2 * w, 1, cssColor);
        }
      }

      function makeSurface(w, h, drawer) {
        var s = g.game.resourceFactory.createSurface(Math.ceil(w), Math.ceil(h));
        var r = s.renderer();
        r.begin();
        drawer(r);
        r.end();
        return s;
      }

      function animate(e, motions) {
        var onEnd = new g.Trigger();
        var frameTime = 1000 / g.game.fps;
        var step = 0;
        var time = 0;
        var mot = motions[0];
        var ended = false;

        function update(delta) {
          time += delta;

          if (time > mot.duration) {
            ended = ++step >= motions.length;

            if (ended) {
              time = mot.duration;
              e.scene.onUpdate.addOnce(onEnd.fire, onEnd);
            } else {
              time -= mot.duration;
              mot = motions[step];
            }
          }

          var r = Math.min(1, time / mot.duration);
          var scale = mot.scale,
              opacity = mot.opacity;
          if (scale) e.scaleX = e.scaleY = scale[0] + (scale[1] - scale[0]) * r;
          if (opacity) e.opacity = opacity[0] + (opacity[1] - opacity[0]) * r;
          e.modified();
          return ended;
        }

        update(0);
        e.onUpdate.add(function () {
          return update(frameTime);
        });
        return onEnd;
      }

      var FallbackDialog =
      /** @class */
      function () {
        function FallbackDialog(name) {
          var _this = this;

          this.onEnd = new g.Trigger();
          this.isHoverPluginStarted = false;
          this.timer = null;
          if (!FallbackDialog.isSupported()) return;
          var game = g.game;
          var gameWidth = game.width,
              gameHeight = game.height;
          var baseWidth = 1280;
          var ratio = gameWidth / baseWidth;
          var titleFontSize = Math.round(32 * ratio);
          var fontSize = Math.round(28 * ratio);
          var lineMarginRate = 0.3;
          var lineHeightRate = 1 + lineMarginRate;
          var titleTopMargin = 80 * ratio;
          var titleBotMargin = 32 * ratio;
          var buttonTopMargin = 42 * ratio;
          var buttonWidth = 360 * ratio;
          var buttonHeight = 82 * ratio;
          var buttonBotMargin = 72 * ratio;
          var colorBlue = "#4a8de1";
          var colorWhite = "#fff";
          var dialogWidth = 960 * ratio | 0;
          var dialogHeight = titleTopMargin + titleFontSize * lineHeightRate * 2 + titleBotMargin + (fontSize + fontSize * lineHeightRate) + // 一行目のマージンは titleBotMargin に繰り込まれている
          buttonTopMargin + buttonHeight + buttonBotMargin | 0;
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: g.FontFamily.SansSerif,
            size: titleFontSize,
            fontWeight: g.FontWeight.Bold,
            fontColor: "#252525"
          });
          var surfSize = Math.ceil(32 * ratio) & ~1; // 切り上げて偶数に丸める

          var surfHalf = surfSize / 2;
          var dialogBgSurf = makeSurface(surfSize, surfSize, function (r) {
            return drawCircle(r, surfHalf, surfHalf, surfHalf, colorWhite);
          });
          var btnActiveBgSurf = makeSurface(surfSize, surfSize, function (r) {
            return drawCircle(r, surfHalf, surfHalf, surfHalf, colorBlue);
          });
          var btnBgSurf = makeSurface(surfSize, surfSize, function (r) {
            drawCircle(r, surfHalf, surfHalf, surfHalf, colorBlue);
            drawCircle(r, surfHalf, surfHalf, 12 * ratio, colorWhite);
          });

          function makeLabel(param) {
            return new g.Label(__assign({
              scene: scene,
              font: font,
              local: true,
              textAlign: g.TextAlign.Center,
              widthAutoAdjust: false
            }, param));
          }

          var scene = this.scene = game.scene();
          var bg = this.bgRect = new g.FilledRect({
            scene: scene,
            local: true,
            width: gameWidth,
            height: gameHeight,
            cssColor: "rgba(0, 0, 0, 0.5)",
            touchable: true // 後ろの touch を奪って modal にする

          });
          var dialogPane = this.dialogPane = new g.Pane({
            scene: scene,
            local: true,
            width: dialogWidth,
            height: dialogHeight,
            anchorX: 0.5,
            anchorY: 0.5,
            x: game.width / 2 | 0,
            y: game.height / 2 | 0,
            backgroundImage: dialogBgSurf,
            backgroundEffector: new g.NinePatchSurfaceEffector(game, dialogBgSurf.width / 2 - 1),
            parent: bg
          });
          var dialogTextX = 80 * ratio | 0;
          var dialogTextWidth = 800 * ratio | 0;
          var y = 0;
          y += titleTopMargin + titleFontSize * lineMarginRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "このコンテンツは名前を利用します。",
            fontSize: titleFontSize,
            width: dialogTextWidth
          }));
          y += titleFontSize * lineHeightRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "\u3042\u306A\u305F\u306F\u300C" + name + "\u300D\u3067\u3059\u3002",
            fontSize: titleFontSize,
            width: dialogTextWidth
          }));
          y += titleFontSize + titleBotMargin | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "ユーザ名で参加するには、",
            fontSize: fontSize,
            width: dialogTextWidth
          }));
          y += fontSize * lineHeightRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "最新のニコニコ生放送アプリに更新してください。",
            fontSize: fontSize,
            width: dialogTextWidth
          }));
          y += fontSize + buttonTopMargin | 0;
          var buttonPane = new g.Pane({
            scene: scene,
            local: true,
            width: buttonWidth,
            height: buttonHeight,
            x: dialogWidth / 2,
            y: y + buttonHeight / 2,
            anchorX: 0.5,
            anchorY: 0.5,
            backgroundImage: btnBgSurf,
            backgroundEffector: new g.NinePatchSurfaceEffector(game, btnBgSurf.width / 2 - 1),
            parent: scene,
            touchable: true
          });
          dialogPane.append(buttonPane);
          var buttonLabel = this.buttonLabel = makeLabel({
            x: 0,
            y: (buttonHeight - titleFontSize) / 2 - 5 * ratio,
            text: "OK (15)",
            fontSize: titleFontSize,
            width: buttonWidth,
            textColor: colorBlue
          });
          buttonPane.append(buttonLabel);

          var activateButton = function activateButton() {
            buttonPane.backgroundImage = btnActiveBgSurf;
            buttonPane.invalidate();
            buttonLabel.textColor = colorWhite;
            buttonLabel.invalidate();
          };

          var deactivateButton = function deactivateButton() {
            buttonPane.backgroundImage = btnBgSurf;
            buttonPane.invalidate();
            buttonLabel.textColor = colorBlue;
            buttonLabel.invalidate();
          };

          var h = akashic_hover_plugin_1.Converter.asHoverable(buttonPane);
          var animating = false;
          h.hovered.add(function () {
            activateButton();
            if (animating) return;
            animating = true;
            animate(buttonPane, [{
              duration: 16,
              scale: [1.0, 0.9]
            }, {
              duration: 16,
              scale: [0.9, 1.1]
            }, {
              duration: 33,
              scale: [1.1, 1.0]
            }]).add(function () {
              return animating = false;
            });
          });
          h.unhovered.add(deactivateButton);
          buttonPane.onPointDown.add(activateButton);
          buttonPane.onPointUp.add(function () {
            _this.end();
          });
          if (!game.operationPluginManager.plugins[FallbackDialog.HOVER_PLUGIN_OPCODE]) game.operationPluginManager.register(HoverPlugin, FallbackDialog.HOVER_PLUGIN_OPCODE);
        }

        FallbackDialog.isSupported = function () {
          // 縦横比 0.4 について: このダイアログは 16:9 の解像度で画面高さの約 65% (468px) を占有する。
          // すなわち画面高さが画面幅の約 37% 以下の場合画面に収まらない。余裕を見て 40% を下限とする。
          // (詳細な高さは下の dialogHeight の定義を参照せよ)
          return typeof window !== "undefined" && g.game.height / g.game.width >= 0.4 && HoverPlugin.isSupported();
        };

        FallbackDialog.prototype.start = function (remainingSeconds) {
          var _this = this;

          var game = g.game;
          var scene = this.scene;

          if (game.scene() !== scene) {
            // ないはずの異常系だが一応確認
            return;
          } // エッジケース考慮: hoverプラグインは必ず停止したいので、シーンが変わった時点で止めてしまう。
          // (mouseover契機で無駄にエンティティ検索したくない)


          game.onSceneChange.add(this._disablePluginOnSceneChange, this);
          game.operationPluginManager.start(FallbackDialog.HOVER_PLUGIN_OPCODE);
          this.isHoverPluginStarted = true;
          animate(this.dialogPane, [{
            duration: 100,
            scale: [0.5, 1.1],
            opacity: [0.5, 1.0]
          }, {
            duration: 100,
            scale: [1.1, 1.0],
            opacity: [1.0, 1.0]
          }]);
          scene.append(this.bgRect);
          scene.onUpdate.add(this._assureFrontmost, this);
          this.timer = scene.setInterval(function () {
            remainingSeconds -= 1;
            _this.buttonLabel.text = "OK (" + remainingSeconds + ")";

            _this.buttonLabel.invalidate();

            if (remainingSeconds <= 0) {
              _this.end();
            }
          }, 1000);
        };

        FallbackDialog.prototype.end = function () {
          var _this = this;

          if (this.timer) {
            this.scene.clearInterval(this.timer);
            this.timer = null;
          } // 厳密には下のアニメーション終了後に解除する方がよいが、
          // 途中でシーンが破棄されるエッジケースを想定してこの時点で止める。


          this.scene.onUpdate.remove(this._assureFrontmost, this);

          if (this.isHoverPluginStarted) {
            g.game.operationPluginManager.stop(FallbackDialog.HOVER_PLUGIN_OPCODE);
            this.isHoverPluginStarted = false;
          }

          animate(this.dialogPane, [{
            duration: 100,
            opacity: [1, 0],
            scale: [1, 0.8]
          }]);
          var t = animate(this.bgRect, [{
            duration: 100,
            opacity: [1, 0]
          }]);
          t.add(function () {
            var onEnd = _this.onEnd;
            _this.onEnd = null;

            _this.bgRect.destroy();

            _this.bgRect = null;
            _this.dialogPane = null;
            _this.scene = null;
            onEnd.fire();
          });
        };

        FallbackDialog.prototype._disablePluginOnSceneChange = function (scene) {
          if (scene !== this.scene) {
            g.game.operationPluginManager.stop(FallbackDialog.HOVER_PLUGIN_OPCODE);
            return true;
          }
        }; // フレーム終了時に確実に画面最前面に持ってくる


        FallbackDialog.prototype._assureFrontmost = function () {
          g.game._pushPostTickTask(this._doAssureFrontmost, this);
        };

        FallbackDialog.prototype._doAssureFrontmost = function () {
          var scene = this.scene;
          if (scene && g.game.scene() !== scene) return;
          if (scene.children[scene.children.length - 1] === this.bgRect) return;
          this.bgRect.remove();
          scene.append(this.bgRect);
        };

        FallbackDialog.HOVER_PLUGIN_OPCODE = -1000; // TODO: 定数予約

        return FallbackDialog;
      }();

      exports.FallbackDialog = FallbackDialog;
    }, {
      "@akashic-extension/akashic-hover-plugin": 3,
      "@akashic-extension/akashic-hover-plugin/lib/HoverPlugin": 2
    }],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.resolvePlayerInfo = void 0;

      var FallbackDialog_1 = require("./FallbackDialog");

      var rpgAtsumaru = typeof window !== "undefined" ? window.RPGAtsumaru : undefined;

      function createRandomName() {
        return "ゲスト" + (Math.random() * 1000 | 0);
      }

      var resolvers = [// window.RPGAtsumaru
      {
        isSupported: function isSupported() {
          return !!(rpgAtsumaru && rpgAtsumaru.user && rpgAtsumaru.user.getSelfInformation);
        },
        resolve: function resolve(_limitSeconds, callback) {
          rpgAtsumaru.user.getSelfInformation().then(function (selfInfo) {
            callback(null, {
              name: selfInfo.name,
              userData: {
                accepted: true,
                premium: selfInfo.isPremium
              }
            });
          }, function (err) {
            callback(err, null);
          });
        }
      }, // coeLimited
      {
        isSupported: function isSupported() {
          var coeLimited = g.game.external.coeLimited;
          return !!(coeLimited && coeLimited.startLocalSession && coeLimited.exitLocalSession);
        },
        resolve: function resolve(limitSeconds, callback) {
          var sessionId = g.game.playId + "__player-info-resolver";
          var scene = g.game.scene();
          var timeoutId = scene.setTimeout(function () {
            timeoutId = null; // NOTE: スキップ時は既に終了済みのローカルセッション自体が起動せず messageHandler() も呼ばれなるため、
            // ここで callback() を呼ばないとコンテンツ側がコールバックをいつまでも待ってしまう状態になってしまう

            callback(null, {
              name: null,
              userData: {
                accepted: false,
                premium: false
              }
            }); // NOTE: リアルタイム視聴の場合、大半のケースではこちらのパスには到達しないはず
            // (仮に到達しても同一セッションIDの COE#exitSession() が呼ばれるのみ)
            // 追っかけ再生またはタイムシフトによる視聴においては、
            // player-info-resolver の自発終了よりも先に以下の exitLocalSession() を呼ぶことで
            // 「スキップ中のセッション起動を抑止する」というプラットフォーム側の機能を有効にしている

            g.game.external.coeLimited.exitLocalSession(sessionId, {
              needsResult: true
            });
          }, (limitSeconds + 2) * 1000); // NOTE: 読み込みなどを考慮して 2 秒のバッファを取る

          g.game.external.coeLimited.startLocalSession({
            sessionId: sessionId,
            applicationName: "player-info-resolver",
            localEvents: [[32, 0, ":akashic", {
              type: "start",
              parameters: {
                limitSeconds: limitSeconds
              }
            }]],
            messageHandler: function messageHandler(message) {
              if (timeoutId == null) {
                // 先にタイムアウト処理が実行されていたら何もしない
                return;
              }

              scene.clearTimeout(timeoutId); // TODO 引数からエラーを取得できるようになったら、異常系の処理も行う

              callback(null, message.result);
            }
          });
        }
      }, // g.game.external.atsumaru
      {
        isSupported: function isSupported() {
          var atsumaru = g.game.external.atsumaru;
          return !!(atsumaru && atsumaru.getSelfInformationProto);
        },
        resolve: function resolve(_limitSeconds, _callback) {
          g.game.external.atsumaru.getSelfInformationProto({
            callback: function callback(errorMessage, result) {
              if (errorMessage != null) {
                _callback(new Error(errorMessage), null);

                return;
              }

              if (result && result.login) {
                _callback(null, {
                  name: result.name,
                  userData: {
                    accepted: true,
                    premium: result.premium
                  }
                });
              } else {
                _callback(null, {
                  name: createRandomName(),
                  userData: {
                    accepted: false,
                    premium: false
                  }
                });
              }
            }
          });
        }
      }, // FallbackDialog
      {
        isSupported: FallbackDialog_1.FallbackDialog.isSupported,
        resolve: function resolve(limitSeconds, callback) {
          var name = createRandomName();
          var dialog = new FallbackDialog_1.FallbackDialog(name);
          dialog.start(limitSeconds);
          dialog.onEnd.addOnce(function () {
            callback(null, {
              name: name,
              userData: {
                accepted: false,
                premium: false
              }
            });
          });
        }
      }, // sentinel
      {
        isSupported: function isSupported() {
          return true;
        },
        resolve: function resolve(_limitSeconds, callback) {
          callback(null, {
            name: "",
            userData: {
              accepted: false,
              premium: false,
              unnamed: true
            }
          });
        }
      }];
      var DEFAULT_LIMIT_SECONDS = 15; // resolvePlayerInfo() の多重呼び出し防止フラグ

      var isResolving = false;

      function find(xs, pred) {
        for (var i = 0; i < xs.length; ++i) {
          if (pred(xs[i])) return xs[i];
        }

        return undefined;
      }
      /**
       * ユーザー情報の取得と通知を行う
       * @param opts ユーザ情報取得時のオプション
       * @param callback 指定された場合、playerInfo が取得成功・失敗した時点の次の local/non-local tick で呼び出される
       */


      exports.resolvePlayerInfo = function (opts, callback) {
        if (isResolving) {
          callback === null || callback === void 0 ? void 0 : callback(new Error("Last processing has not yet been completed."), null);
          return;
        }

        var cb = function cb(err, info) {
          isResolving = false;
          callback === null || callback === void 0 ? void 0 : callback(err, info);

          if (!err) {
            var _a = info,
                name_1 = _a.name,
                userData = _a.userData;

            if (opts && opts.raises && (!userData || !userData.unnamed)) {
              g.game.raiseEvent(new g.PlayerInfoEvent({
                id: g.game.selfId,
                name: name_1,
                userData: userData
              }));
            }
          }
        };

        var limitSeconds = opts && opts.limitSeconds ? opts.limitSeconds : DEFAULT_LIMIT_SECONDS;
        var resolver = find(resolvers, function (r) {
          return r.isSupported();
        }); // isSupported() が恒真の実装があるので non-null

        try {
          isResolving = true;
          resolver.resolve(limitSeconds, cb);
        } catch (e) {
          cb(e);
        }
      };
    }, {
      "./FallbackDialog": 4
    }],
    6: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics = function extendStatics(d, b) {
          _extendStatics = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
            }
          };

          return _extendStatics(d, b);
        };

        return function (d, b) {
          if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

          _extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.MainGame = void 0;

      var Player_1 = require("./Player");

      var MainGame =
      /** @class */
      function (_super) {
        __extends(MainGame, _super);

        function MainGame() {
          var _this = this;

          var scene = g.game.scene();
          _this = _super.call(this, {
            scene: scene,
            width: g.game.width,
            height: g.game.height,
            touchable: true
          }) || this;

          _this.init = function (pid) {};

          _this.colors = ["#ff5050", "green", "yellow", "blue"];
          var players = {};
          var gameState = "start"; // マップの親(スケールのxとyを伸縮させて疑似的に奥行きを表現)

          var mapBase = new g.E({
            scene: scene,
            x: g.game.width / 2,
            y: g.game.height / 2 + 250,
            width: 0,
            height: 0,
            anchorX: 0,
            anchorY: 0,
            scaleY: 0.8,
            scaleX: 5.0,
            parent: _this
          }); //床

          var floor = new g.FilledRect({
            scene: scene,
            x: 0,
            y: 0,
            width: 2000,
            height: 2000,
            anchorX: 0.5,
            anchorY: 0.5,
            angle: 0,
            cssColor: "gray",
            parent: mapBase
          }); //マップチップ

          var maps = [];

          for (var y = 0; y < 20; y++) {
            maps[y] = [];

            for (var x = 0; x < 20; x++) {
              maps[y].push(new g.FilledRect({
                scene: scene,
                x: x * 100,
                y: y * 100,
                width: 100 - 2,
                height: 100 - 2,
                cssColor: "white",
                parent: floor,
                tag: -1
              }));
            }
          } // ユニット配置用


          var unitBase = new g.E({
            scene: scene,
            parent: _this
          });
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: "sans-serif",
            size: 50
          }); // 上で生成した font.png と font_glyphs.json に対応するアセットを取得

          var fontAsset = g.game.scene().asset.getImageById("number");
          var fontGlyphAsset = g.game.scene().asset.getTextById("glyph"); // テキストアセット (JSON) の内容をオブジェクトに変換

          var glyphInfo = JSON.parse(fontGlyphAsset.data); // ビットマップフォントを生成

          var fontNum = new g.BitmapFont({
            src: fontAsset,
            glyphInfo: glyphInfo
          }); //残り時間表示

          new g.Sprite({
            scene: scene,
            src: g.game.scene().asset.getImageById("time"),
            x: 500,
            y: 25,
            parent: _this
          });
          var timeLimit = 90;
          var labelTime = new g.Label({
            scene: scene,
            x: 600,
            y: 30,
            font: fontNum,
            text: "90",
            parent: _this
          }); //マップの色ごとの数表示用

          var numColor = 4;
          var labelColors = [];

          for (var i = 0; i < numColor; i++) {
            var rect = new g.FilledRect({
              scene: scene,
              x: 1000,
              y: 150 * i + 50,
              width: 80,
              height: 80,
              cssColor: _this.colors[i],
              parent: _this
            });
            labelColors.push(new g.Label({
              scene: scene,
              x: 90,
              y: 10,
              font: fontNum,
              text: "0",
              parent: rect
            }));
          } //スタート表示用


          var startBase = new g.E({
            scene: scene,
            parent: _this
          });
          var rectStart = new g.FilledRect({
            scene: scene,
            width: g.game.width,
            height: g.game.height,
            cssColor: "black",
            opacity: 0.5,
            parent: startBase
          });
          var sprStart = new g.FrameSprite({
            scene: scene,
            src: scene.asset.getImageById("start"),
            x: (g.game.width - 800) / 2,
            y: (g.game.height - 250) / 2,
            width: 800,
            height: 250,
            frameNumber: 0,
            frames: [0, 1],
            parent: startBase
          }); // デバッグ用文字列

          var debugText = new g.Label({
            scene: scene,
            y: g.game.height - 50,
            font: font,
            text: "",
            textColor: "red",
            parent: _this
          });
          floor.onUpdate.add(function () {// floor.angle += 0.3;
            // floor.modified();
          }); //キーイベントを受け取る

          _this.onMessage.add(function (msg) {
            if (gameState != "play") return; // 関係ないイベントは無視して抜ける

            if (!msg.data) return;
            var ev = msg.data; //矢印キーを押したとき

            if (ev.key) {
              var player = players[msg.player.id];
              if (!player) return;

              if (ev.isPush) {
                // 移動速度を設定
                if (ev.key == "ArrowUp") {
                  player.speed = 10;
                }

                if (ev.key == "ArrowDown") {
                  player.speed = -10;
                }

                if (ev.key == "ArrowRight") {
                  player.rotate = 2;
                }

                if (ev.key == "ArrowLeft") {
                  player.rotate = -2;
                }
              } else {
                // 移動速度を0にする
                if (ev.key == "ArrowUp") {
                  player.speed = 0;
                }

                if (ev.key == "ArrowDown") {
                  player.speed = 0;
                }

                if (ev.key == "ArrowRight") {
                  player.rotate = 0;
                }

                if (ev.key == "ArrowLeft") {
                  player.rotate = 0;
                } // if (ev.key == "a" || ev.key == "A") {
                // 	player.setColor();
                // }

              }
            }
          });

          _this.onPointMove.add(function (ev) {
            if (gameState != "play") return;
            var player = players[ev.player.id];

            if (player) {
              var px = ev.point.x + ev.startDelta.x;
              var py = ev.point.y + ev.startDelta.y;

              if (py < _this.height / 3 * 2) {
                player.speed = 10;
              } else {
                player.speed = -10;
              }

              if (px < _this.width / 3) {
                player.rotate = -2;
              } else if (px > _this.width / 3 * 2) {
                player.rotate = 2;
              } else {
                player.rotate = 0;
              }
            }
          });

          _this.onPointUp.add(function (ev) {
            if (gameState != "play") return;
            var player = players[ev.player.id];

            if (player) {
              player.speed = 0;
              player.rotate = 0;
            }
          });

          var move = function move() {
            var _a; //移動


            for (var key in players) {
              var player_1 = players[key];
              player_1.move(); //床を塗る

              if (player_1.speed != 0) {
                var mx = Math.floor(player_1.base.x / 100);
                var my = Math.floor(player_1.base.y / 100);
                var map = maps[my][mx];
                map.cssColor = _this.colors[player_1.numColor];
                map.modified();
                map.tag = player_1.numColor;
              }
            } //視点移動


            var player = players[g.game.selfId];
            if (!player) player = players[g.game.vars.gameMasterId];
            floor.anchorX = player.base.x / floor.width;
            floor.anchorY = player.base.y / floor.height;
            floor.angle = -player.angle - 90;
            floor.modified();

            if (player.speed > 0) {
              if (player.rotate == 0) {
                player.unit.frameNumber = 4;
              } else if (player.rotate > 0) {
                player.unit.frameNumber = 5;
              } else if (player.rotate < 0) {
                player.unit.frameNumber = 3;
              }
            } else if (player.speed < 0) {
              if (player.rotate == 0) {
                player.unit.frameNumber = 0;
              } else if (player.rotate > 0) {
                player.unit.frameNumber = 7;
              } else if (player.rotate < 0) {
                player.unit.frameNumber = 1;
              }
            }

            player.unit.modified(); //重ね順ソート

            (_a = unitBase.children) === null || _a === void 0 ? void 0 : _a.sort(function (a, b) {
              return a.y - b.y;
            });
          };

          _this.onUpdate.add(function () {
            if (gameState != "play") return; //残り時間を更新

            timeLimit -= 1 / 30;
            labelTime.text = "" + Math.max(0, Math.floor(timeLimit));
            labelTime.invalidate();

            if (0 >= Math.ceil(timeLimit)) {
              gameState = "finish";
            }

            move(); //マップの色数を数える

            var colorCnt = [0, 0, 0, 0, 0];

            for (var y = 0; y < maps.length; y++) {
              for (var x = 0; x < maps[y].length; x++) {
                if (maps[y][x].tag != -1) {
                  colorCnt[maps[y][x].tag]++;
                }
              }
            }

            for (var i = 0; i < numColor; i++) {
              labelColors[i].text = "" + colorCnt[i];
              labelColors[i].invalidate();
            }
          }); //初期化


          _this.init = function (playerIds) {
            for (var i = 0; i < playerIds.length; i++) {
              var player = new Player_1.Player(floor, unitBase, i, playerIds[i].name);
              player.numColor = i % numColor;
              players[playerIds[i].id] = player;
            }

            move();
            scene.setTimeout(function () {
              startBase.remove();
              gameState = "play";
            }, 3000);
          };

          return _this;
        }

        return MainGame;
      }(g.E);

      exports.MainGame = MainGame;
    }, {
      "./Player": 7
    }],
    7: [function (require, module, exports) {
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Player = void 0; //プレイヤークラス

      var Player =
      /** @class */
      function () {
        function Player(rectFloor, rectMain, num, name) {
          this.rectFloor = rectFloor;
          this.rectMain = rectMain;
          this.speed = 0;
          this.rotate = 0; //回転速度

          this.angle = 45; //角度

          this.numColor = 0;

          if (!Player.font) {
            Player.font = new g.DynamicFont({
              game: g.game,
              fontFamily: "sans-serif",
              size: 25
            });
          }

          this.base = new g.FilledRect({
            scene: g.game.scene(),
            x: rectFloor.width / 2 + num * 30,
            y: rectFloor.height / 2,
            width: 30,
            height: 30,
            anchorX: 0.5,
            anchorY: 0.5,
            cssColor: "black",
            opacity: 0.2,
            parent: this.rectFloor
          });
          this.unit = new g.FrameSprite({
            scene: g.game.scene(),
            width: 187.5,
            height: 250,
            anchorX: 0.5,
            anchorY: 0.85,
            scaleX: 1.3,
            scaleY: 1.3,
            src: g.game.scene().asset.getImageById("kaeru"),
            frames: [0, 1, 2, 3, 4, 5, 6, 7, 8],
            parent: this.rectMain
          });
          new g.Label({
            scene: g.game.scene(),
            x: this.unit.width / 2,
            width: 500,
            anchorX: 0.5,
            anchorY: 0.5,
            font: Player.font,
            fontSize: 25,
            textAlign: "center",
            widthAutoAdjust: false,
            text: name,
            parent: this.unit
          });
        }

        Player.prototype.move = function () {
          if (this.speed >= 0) {
            this.angle += this.rotate;
          } else {
            this.angle -= this.rotate;
          }

          var moveX = this.speed * Math.cos(this.angle * (Math.PI / 180));
          var moveY = this.speed * Math.sin(this.angle * (Math.PI / 180));
          this.base.x += moveX;
          this.base.y += moveY;
          this.base.x = Math.max(5, Math.min(this.base.x, this.rectFloor.width - 5));
          this.base.y = Math.max(5, Math.min(this.base.y, this.rectFloor.height - 5));
          this.base.modified(); //カエルの位置を変更し表示

          var gp = this.rectFloor.localToGlobal(this.base);
          this.unit.x = gp.x;
          this.unit.y = gp.y;
          this.unit.modified();
        };

        Player.prototype.setColor = function () {
          this.numColor = (this.numColor + 1) % 4; //this.unit.cssColor = this.colors[this.numColor];
          //this.unit.modified();
        };

        return Player;
      }();

      exports.Player = Player;
    }, {}],
    8: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics2 = function extendStatics(d, b) {
          _extendStatics2 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
            }
          };

          return _extendStatics2(d, b);
        };

        return function (d, b) {
          if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

          _extendStatics2(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Title = void 0;

      var resolve_player_info_1 = require("@akashic-extension/resolve-player-info"); //参加待ち画面


      var Title =
      /** @class */
      function (_super) {
        __extends(Title, _super);

        function Title() {
          var _this = this;

          var scene = g.game.scene();
          _this = _super.call(this, {
            scene: scene,
            parent: scene
          }) || this;

          _this.start = function () {};

          var playerIds = [];
          var title = new g.Sprite({
            scene: scene,
            x: 123,
            width: 1034,
            height: 720,
            src: scene.asset.getImageById("title"),
            parent: _this
          });
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: "sans-serif",
            size: 50
          });
          var label = new g.Label({
            scene: scene,
            font: font,
            text: "キーボード　↑:前進　↓:後退　←→:回転　A:色変更",
            fontSize: 30,
            textColor: "yellow",
            parent: _this
          });
          new g.Label({
            scene: scene,
            x: 40,
            y: 180,
            font: font,
            text: "カエルトゥーン",
            fontSize: 80,
            textColor: "white",
            parent: title
          });
          var players = {}; // 参加ボタン

          var button = new g.FilledRect({
            scene: scene,
            x: 100,
            y: 400,
            width: 200,
            height: 80,
            cssColor: "white",
            parent: title,
            touchable: true,
            local: true
          });
          var labelButton = new g.Label({
            scene: scene,
            font: font,
            y: 10,
            width: 200,
            text: "参加",
            fontSize: 50,
            textColor: "black",
            textAlign: "center",
            widthAutoAdjust: false,
            parent: button
          }); // 開始ボタン

          var buttonStart = new g.FilledRect({
            scene: scene,
            x: 350,
            y: 400,
            width: 200,
            height: 80,
            cssColor: "white",
            parent: title,
            touchable: true,
            local: true
          });
          buttonStart.hide();
          new g.Label({
            scene: scene,
            font: font,
            y: 10,
            width: 200,
            text: "開始",
            fontSize: 50,
            textColor: "black",
            textAlign: "center",
            widthAutoAdjust: false,
            parent: buttonStart
          }); // 参加人数表示

          var labelCount = new g.Label({
            scene: scene,
            font: font,
            y: -60,
            width: 200,
            text: "0人",
            fontSize: 50,
            textColor: "white",
            textAlign: "center",
            widthAutoAdjust: false,
            parent: button
          }); //ユーザーネーム取得ダイアログからの操作

          g.game.onPlayerInfo.add(function (ev) {
            playerIds.push(ev.player);
            labelCount.text = playerIds.length + "人";
            labelCount.invalidate();
          }); // 参加

          button.onPointDown.add(function (e) {
            (0, resolve_player_info_1.resolvePlayerInfo)({
              raises: true
            });
            button.touchable = false;
            labelButton.text = "参加済み";
            labelButton.invalidate(); //キーボードイベント設定

            document.addEventListener("keydown", function (ev) {
              ev.preventDefault();
              g.game.raiseEvent(new g.MessageEvent({
                isPush: true,
                key: ev.key
              }));
            });
            document.addEventListener("keyup", function (ev) {
              ev.preventDefault();
              g.game.raiseEvent(new g.MessageEvent({
                isPush: false,
                key: ev.key
              }));
            });
            focus(); //フォーカス
          }); // 開始

          buttonStart.onPointDown.add(function () {
            g.game.raiseEvent(new g.MessageEvent({
              name: "start"
            }));
          }); //キーイベントを受け取る

          scene.onMessage.add(function (msg) {
            // 関係ないイベントは無視して抜ける
            if (!msg.data) return; //参加ボタンを押したとき

            if (msg.data.name == "join") {
              playerIds.push(msg.player);
              labelCount.text = playerIds.length + "人";
              labelCount.invalidate();
            } //開始ボタンを押したとき


            if (msg.data.name == "start") {
              _this.start(playerIds);
            }
          });

          _this.onUpdate.add(function () {
            //放送者の場合、開始ボタンを表示
            if (!buttonStart.visible()) {
              if (g.game.vars.gameMasterId === g.game.selfId) {
                buttonStart.show();
              }
            }
          });

          return _this;
        }

        return Title;
      }(g.E);

      exports.Title = Title;
    }, {
      "@akashic-extension/resolve-player-info": 5
    }],
    9: [function (require, module, exports) {
      var main_1 = require("./main");

      module.exports = function (originalParam) {
        var param = {};
        Object.keys(originalParam).forEach(function (key) {
          param[key] = originalParam[key];
        }); // セッションパラメーター

        param.sessionParameter = {}; // コンテンツが動作している環境がゲームアツマール上かどうか

        param.isAtsumaru = typeof window !== "undefined" && typeof window.RPGAtsumaru !== "undefined"; // 乱数生成器

        param.random = g.game.random;
        var limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数

        var scene = new g.Scene({
          game: g.game,
          name: "_bootstrap"
        }); // セッションパラメーターを受け取ってゲームを開始します

        scene.onMessage.add(function (msg) {
          if (msg.data && msg.data.type === "start" && msg.data.parameters) {
            param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加

            if (msg.data.parameters.randomSeed != null) {
              param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
            }

            g.game.popScene();
            (0, main_1.main)(param);
          }
        });
        scene.onLoad.add(function () {
          var currentTickCount = 0;
          scene.onUpdate.add(function () {
            currentTickCount++; // 待ち時間を超えた場合はゲームを開始します

            if (currentTickCount > limitTickToWait) {
              g.game.popScene();
              (0, main_1.main)(param);
            }
          });
        });
        g.game.pushScene(scene);
      };
    }, {
      "./main": 10
    }],
    10: [function (require, module, exports) {
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.main = void 0;

      var Title_1 = require("./Title");

      var MainGame_1 = require("./MainGame");

      function main(param) {
        var scene = new g.Scene({
          game: g.game,
          // このシーンで利用するアセットのIDを列挙し、シーンに通知します
          assetIds: ["kaeru", "title", "start", "time", "number", "glyph"]
        }); // 放送者を区別する

        g.game.vars.gameMasterId = null;
        g.game.onJoin.addOnce(function (e) {
          g.game.vars.gameMasterId = e.player.id;
        }); // 市場コンテンツのランキングモードでは、g.game.vars.gameState.score の値をスコアとして扱います

        g.game.vars.gameState = {
          score: 0
        };
        scene.onLoad.add(function () {
          // 背景
          var bg = new g.FilledRect({
            scene: scene,
            width: g.game.width,
            height: g.game.height,
            cssColor: "black",
            opacity: 0.5,
            parent: scene
          });
          var title = new Title_1.Title();

          title.start = function (playerIds) {
            title.remove();
            var mainGame = new MainGame_1.MainGame();
            scene.append(mainGame);
            mainGame.init(playerIds);
          };
        });
        g.game.pushScene(scene);
      }

      exports.main = main;
    }, {
      "./MainGame": 6,
      "./Title": 8
    }]
  }, {}, [9])(9);
});