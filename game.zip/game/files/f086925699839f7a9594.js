function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      var main_1 = require("./main");

      module.exports = function (originalParam) {
        var param = {};
        Object.keys(originalParam).forEach(function (key) {
          param[key] = originalParam[key];
        }); // セッションパラメーター

        param.sessionParameter = {}; // コンテンツが動作している環境がゲームアツマール上かどうか

        param.isAtsumaru = typeof window !== "undefined" && typeof window.RPGAtsumaru !== "undefined"; // 乱数生成器

        param.random = g.game.random;
        var limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数

        var scene = new g.Scene({
          game: g.game,
          name: "_bootstrap"
        }); // セッションパラメーターを受け取ってゲームを開始します

        scene.onMessage.add(function (msg) {
          if (msg.data && msg.data.type === "start" && msg.data.parameters) {
            param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加

            if (msg.data.parameters.randomSeed != null) {
              param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
            }

            g.game.popScene();
            (0, main_1.main)(param);
          }
        });
        scene.onLoad.add(function () {
          var currentTickCount = 0;
          scene.onUpdate.add(function () {
            currentTickCount++; // 待ち時間を超えた場合はゲームを開始します

            if (currentTickCount > limitTickToWait) {
              g.game.popScene();
              (0, main_1.main)(param);
            }
          });
        });
        g.game.pushScene(scene);
      };
    }, {
      "./main": 2
    }],
    2: [function (require, module, exports) {
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.main = void 0;

      function main(param) {
        var scene = new g.Scene({
          game: g.game // このシーンで利用するアセットのIDを列挙し、シーンに通知します
          // assetIds: ["player", "shot", "se"],

        }); // 放送者を区別する

        var gameMasterId = null;
        g.game.onJoin.addOnce(function (e) {
          gameMasterId = e.player.id;
        }); // 市場コンテンツのランキングモードでは、g.game.vars.gameState.score の値をスコアとして扱います

        g.game.vars.gameState = {
          score: 0
        };
        scene.onLoad.add(function () {
          var title = new g.FilledRect({
            scene: scene,
            width: g.game.width,
            height: g.game.height,
            cssColor: "white",
            parent: scene
          });
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: "sans-serif",
            size: 50
          });
          var label = new g.Label({
            scene: scene,
            font: font,
            text: "Hello World!",
            fontSize: 50,
            textColor: "black",
            parent: scene,
            local: true
          });
          var players = {}; // 参加ボタン

          var button = new g.FilledRect({
            scene: scene,
            x: (g.game.width - 200) / 2,
            y: (g.game.height - 80) / 2,
            width: 200,
            height: 80,
            cssColor: "yellow",
            parent: title,
            touchable: true,
            local: true
          });
          var labelButton = new g.Label({
            scene: scene,
            font: font,
            y: 10,
            width: 200,
            text: "参加",
            fontSize: 50,
            textColor: "black",
            textAlign: "center",
            widthAutoAdjust: false,
            parent: button
          }); // 開始ボタン

          var buttonStart = new g.FilledRect({
            scene: scene,
            x: (g.game.width - 200) / 2 + 300,
            y: (g.game.height - 80) / 2,
            width: 200,
            height: 80,
            cssColor: "yellow",
            parent: title,
            touchable: true,
            local: true
          });
          buttonStart.hide();
          new g.Label({
            scene: scene,
            font: font,
            y: 10,
            width: 200,
            text: "開始",
            fontSize: 50,
            textColor: "black",
            textAlign: "center",
            widthAutoAdjust: false,
            parent: buttonStart
          });
          var gameBase = new g.E({
            scene: scene,
            parent: scene
          });
          gameBase.hide();
          var mapBase = new g.E({
            scene: scene,
            x: g.game.width / 2,
            y: g.game.height / 2,
            width: 0,
            height: 0,
            anchorX: 0,
            anchorY: 0,
            scaleY: 0.2,
            parent: gameBase
          });
          var floor = new g.FilledRect({
            scene: scene,
            x: 0,
            y: 0,
            width: 1000,
            height: 1000,
            anchorX: 0.5,
            anchorY: 0.5,
            angle: 20,
            cssColor: "yellow",
            parent: mapBase
          }); // ユニット配置用

          var unitBase = new g.E({
            scene: scene,
            parent: gameBase
          });
          floor.onUpdate.add(function () {// floor.angle += 0.3;
            // floor.modified();
          }); // 参加人数表示

          var labelCount = new g.Label({
            scene: scene,
            font: font,
            y: -60,
            width: 200,
            text: "0人",
            fontSize: 50,
            textColor: "black",
            textAlign: "center",
            widthAutoAdjust: false,
            parent: button
          }); // 参加

          button.onPointDown.add(function (e) {
            button.touchable = false;
            labelButton.text = "参加済み";
            focus(); //フォーカス

            g.game.raiseEvent(new g.MessageEvent({
              playerId: e.player.id
            })); //キーボードイベント

            document.addEventListener("keydown", function (ev) {
              ev.preventDefault();
              label.text = ev.key;
              label.invalidate();
              g.game.raiseEvent(new g.MessageEvent({
                isPush: true,
                key: ev.key,
                pId: e.player.id
              }));
            });
            document.addEventListener("keyup", function (ev) {
              ev.preventDefault();
              g.game.raiseEvent(new g.MessageEvent({
                isPush: false,
                key: ev.key,
                pId: e.player.id
              }));
            });
          }); // 開始

          buttonStart.onPointDown.add(function () {
            g.game.raiseEvent(new g.MessageEvent({
              name: "start"
            }));
          }); //キーイベントを受け取る

          scene.onMessage.add(function (msg) {
            // 関係ないイベントは無視して抜ける
            if (!msg.data) return;
            var ev = msg.data;

            if (ev.name == "start") {
              title.hide();
              gameBase.show();
            } //参加ボタンを押したとき


            if (ev.playerId) {
              var player = new Player(floor, unitBase);
              players[ev.playerId] = player;
              labelCount.text = "" + Object.keys(players).length + "人";
              labelCount.invalidate();
            } //矢印キーを押したとき


            if (ev.key) {
              var player = players[ev.pId];

              if (ev.isPush) {
                // if (ev.key == "a" || ev.key == "A") {
                // 	player.cssColor = player.cssColor == "green" ? "blue" : "green";
                // }
                // 移動速度を設定
                if (ev.key == "ArrowUp") {
                  player.moveY = -5;
                }

                if (ev.key == "ArrowDown") {
                  player.moveY = 5;
                }

                if (ev.key == "ArrowRight") {
                  player.moveX = 5;
                }

                if (ev.key == "ArrowLeft") {
                  player.moveX = -5;
                }
              } else {
                // 移動速度を0にする
                if (ev.key == "ArrowUp") {
                  player.moveY = 0;
                }

                if (ev.key == "ArrowDown") {
                  player.moveY = 0;
                }

                if (ev.key == "ArrowRight") {
                  player.moveX = 0;
                }

                if (ev.key == "ArrowLeft") {
                  player.moveX = 0;
                }
              }
            }
          });
          scene.onUpdate.add(function () {
            if (!buttonStart.visible()) {
              if (gameMasterId === g.game.selfId) {
                buttonStart.show();
              }
            }

            for (var key in players) {
              var player = players[key];
              player.move();
            }
          });
        });
        g.game.pushScene(scene);
      }

      exports.main = main; //プレイヤークラス

      var Player =
      /** @class */
      function () {
        function Player(rectFloor, rectMain) {
          this.rectFloor = rectFloor;
          this.rectMain = rectMain;
          this.moveX = 0;
          this.moveY = 0;
          this.base = new g.FilledRect({
            scene: g.game.scene(),
            width: 50,
            height: 50,
            anchorX: 0.5,
            anchorY: 0.5,
            cssColor: "black",
            parent: this.rectFloor
          });
          this.unit = new g.FilledRect({
            scene: g.game.scene(),
            width: 50,
            height: 120,
            anchorX: 0.5,
            anchorY: 1.0,
            cssColor: "red",
            parent: this.rectMain
          });
        }

        Player.prototype.move = function () {
          this.base.x += this.moveX;
          this.base.y += this.moveY;
          this.base.modified();
          var gp = this.rectFloor.localToGlobal(this.base);
          this.unit.x = gp.x;
          this.unit.y = gp.y;
          this.unit.modified();
        };

        return Player;
      }(); // class Player extends g.FilledRect {
      // 	public moveX = 0;
      // 	public moveY = 0;
      // }

    }, {}]
  }, {}, [1])(1);
});