function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * コンバータ機能を提供するクラス。
       */

      var Converter =
      /** @class */
      function () {
        function Converter() {}
        /**
         * エンティティをホバー可能に変換する。
         */


        Converter.asHoverable = function (e, opts) {
          var hoverableE = e;
          hoverableE.hoverable = true;
          hoverableE.touchable = true;
          hoverableE.hovered = hoverableE.hovered || new g.Trigger();
          hoverableE.unhovered = hoverableE.unhovered || new g.Trigger();

          if (opts) {
            if (opts.cursor) hoverableE.cursor = opts.cursor;
          }

          return hoverableE;
        };
        /**
         * エンティティのホバーを解除する。
         */


        Converter.asUnhoverable = function (e) {
          var hoverableE = e;
          delete hoverableE.hoverable;

          if (hoverableE.hovered && !hoverableE.hovered.destroyed()) {
            hoverableE.hovered.destroy();
            delete hoverableE.hovered;
          }

          if (hoverableE.unhovered && !hoverableE.unhovered.destroyed()) {
            hoverableE.unhovered.fire();
            hoverableE.unhovered.destroy();
            delete hoverableE.unhovered;
          }

          return hoverableE;
        };

        return Converter;
      }();

      exports.Converter = Converter;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      /**
       * ホバー機能を提供するプラグイン。
       */

      var HoverPlugin =
      /** @class */
      function () {
        function HoverPlugin(game, view, option) {
          if (option === void 0) {
            option = {};
          }

          this.game = game;
          this.view = view.view;
          this.beforeHover = null;
          this.operationTrigger = new g.Trigger();
          this._cursor = option.cursor || "pointer";
          this._showTooltip = !!option.showTooltip;
          this._getScale = view.getScale ? function () {
            return view.getScale();
          } : null;
          this._onMouseMove_bound = this._onMouseMove.bind(this);
          this._onMouseOut_bound = this._onMouseOut.bind(this);
        }

        HoverPlugin.isSupported = function () {
          return typeof document !== "undefined" && typeof document.addEventListener === "function";
        };

        HoverPlugin.prototype.start = function () {
          this.view.addEventListener("mousemove", this._onMouseMove_bound, false);
          this.view.addEventListener("mouseout", this._onMouseOut_bound, false);
          return true;
        };

        HoverPlugin.prototype.stop = function () {
          this.view.removeEventListener("mousemove", this._onMouseMove_bound, false);
          this.view.removeEventListener("mouseout", this._onMouseOut_bound, false);
        };

        HoverPlugin.prototype._onMouseMove = function (e) {
          var scene = this.game.scene();
          if (!scene) return;
          var rect = this.view.getBoundingClientRect();
          var positionX = rect.left + window.pageXOffset;
          var positionY = rect.top + window.pageYOffset;
          var offsetX = e.pageX - positionX;
          var offsetY = e.pageY - positionY;
          var scale = {
            x: 1,
            y: 1
          };

          if (this._getScale) {
            scale = this._getScale();
          }

          var point = {
            x: offsetX / scale.x,
            y: offsetY / scale.y
          };
          var target = scene.findPointSourceByPoint(point).target;

          if (target && target.hoverable) {
            if (target !== this.beforeHover) {
              if (this.beforeHover && this.beforeHover.hoverable) {
                this._onUnhovered(target);
              }

              this._onHovered(target);
            }

            this.beforeHover = target;
          } else if (this.beforeHover) {
            this._onUnhovered(this.beforeHover);
          }
        };

        HoverPlugin.prototype._onHovered = function (target) {
          if (target.hoverable) {
            this.view.style.cursor = target.cursor ? target.cursor : this._cursor;

            if (this._showTooltip && target.title) {
              this.view.setAttribute("title", target.title);
            }

            target.hovered.fire();
          }
        };

        HoverPlugin.prototype._onUnhovered = function (target) {
          this.view.style.cursor = "auto";

          if (this.beforeHover && this.beforeHover.unhovered) {
            this.beforeHover.unhovered.fire();

            if (this._showTooltip) {
              this.view.removeAttribute("title");
            }
          }

          this.beforeHover = null;
        };

        HoverPlugin.prototype._onMouseOut = function () {
          if (this.beforeHover) this._onUnhovered(this.beforeHover);
        };

        return HoverPlugin;
      }();

      exports.HoverPlugin = HoverPlugin;
      module.exports = HoverPlugin;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Converter_1 = require("./Converter");

      exports.Converter = Converter_1.Converter;
    }, {
      "./Converter": 1
    }],
    4: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.ActionType = void 0;
      var ActionType;

      (function (ActionType) {
        ActionType[ActionType["Wait"] = 0] = "Wait";
        ActionType[ActionType["Call"] = 1] = "Call";
        ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
        ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
        ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
        ActionType[ActionType["Cue"] = 5] = "Cue";
        ActionType[ActionType["Every"] = 6] = "Every";
      })(ActionType = exports.ActionType || (exports.ActionType = {}));
    }, {}],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Easing = void 0;
      /**
       * Easing関数群。
       * 参考: http://gizma.com/easing/
       */

      var Easing;

      (function (Easing) {
        /**
         * 入力値をlinearした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function linear(t, b, c, d) {
          return c * t / d + b;
        }

        Easing.linear = linear;
        /**
         * 入力値をeaseInQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuad(t, b, c, d) {
          t /= d;
          return c * t * t + b;
        }

        Easing.easeInQuad = easeInQuad;
        /**
         * 入力値をeaseOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuad(t, b, c, d) {
          t /= d;
          return -c * t * (t - 2) + b;
        }

        Easing.easeOutQuad = easeOutQuad;
        /**
         * 入力値をeaseInOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuad(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t + b;
          --t;
          return -c / 2 * (t * (t - 2) - 1) + b;
        }

        Easing.easeInOutQuad = easeInOutQuad;
        /**
         * 入力値をeaseInQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCubic(t, b, c, d) {
          t /= d;
          return c * t * t * t + b;
        }

        Easing.easeInCubic = easeInCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
         */

        Easing.easeInQubic = easeInCubic;
        /**
         * 入力値をeaseOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCubic(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t + 1) + b;
        }

        Easing.easeOutCubic = easeOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
         */

        Easing.easeOutQubic = easeOutCubic;
        /**
         * 入力値をeaseInOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCubic(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t + 2) + b;
        }

        Easing.easeInOutCubic = easeInOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
         */

        Easing.easeInOutQubic = easeInOutCubic;
        /**
         * 入力値をeaseInQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuart(t, b, c, d) {
          t /= d;
          return c * t * t * t * t + b;
        }

        Easing.easeInQuart = easeInQuart;
        /**
         * 入力値をeaseOutQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuart(t, b, c, d) {
          t /= d;
          --t;
          return -c * (t * t * t * t - 1) + b;
        }

        Easing.easeOutQuart = easeOutQuart;
        /**
         * 入力値をeaseInQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuint(t, b, c, d) {
          t /= d;
          return c * t * t * t * t * t + b;
        }

        Easing.easeInQuint = easeInQuint;
        /**
         * 入力値をeaseOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuint(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t * t * t + 1) + b;
        }

        Easing.easeOutQuint = easeOutQuint;
        /**
         * 入力値をeaseInOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuint(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t * t * t + 2) + b;
        }

        Easing.easeInOutQuint = easeInOutQuint;
        /**
         * 入力値をeaseInSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInSine(t, b, c, d) {
          return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
        }

        Easing.easeInSine = easeInSine;
        /**
         * 入力値をeaseOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutSine(t, b, c, d) {
          return c * Math.sin(t / d * (Math.PI / 2)) + b;
        }

        Easing.easeOutSine = easeOutSine;
        /**
         * 入力値をeaseInOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutSine(t, b, c, d) {
          return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
        }

        Easing.easeInOutSine = easeInOutSine;
        /**
         * 入力値をeaseInExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInExpo(t, b, c, d) {
          return c * Math.pow(2, 10 * (t / d - 1)) + b;
        }

        Easing.easeInExpo = easeInExpo;
        /**
         * 入力値をeaseInOutExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutExpo(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
          --t;
          return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
        }

        Easing.easeInOutExpo = easeInOutExpo;
        /**
         * 入力値をeaseInCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCirc(t, b, c, d) {
          t /= d;
          return -c * (Math.sqrt(1 - t * t) - 1) + b;
        }

        Easing.easeInCirc = easeInCirc;
        /**
         * 入力値をeaseOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCirc(t, b, c, d) {
          t /= d;
          --t;
          return c * Math.sqrt(1 - t * t) + b;
        }

        Easing.easeOutCirc = easeOutCirc;
        /**
         * 入力値をeaseInOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCirc(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
          t -= 2;
          return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
        }

        Easing.easeInOutCirc = easeInOutCirc;
        /**
         * 入力値を easeInOutBack した結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutBack(t, b, c, d) {
          var x = t / d;
          var c1 = 1.70158;
          var c2 = c1 * 1.525;
          var v = x < 0.5 ? Math.pow(2 * x, 2) * ((c2 + 1) * 2 * x - c2) / 2 : (Math.pow(2 * x - 2, 2) * ((c2 + 1) * (x * 2 - 2) + c2) + 2) / 2;
          return b + c * v;
        }

        Easing.easeInOutBack = easeInOutBack;
        /**
         * 入力値を easeOutBounce した結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutBounce(t, b, c, d) {
          var x = t / d;
          var n1 = 7.5625;
          var d1 = 2.75;
          var v;

          if (x < 1 / d1) {
            v = n1 * x * x;
          } else if (x < 2 / d1) {
            v = n1 * (x -= 1.5 / d1) * x + 0.75;
          } else if (x < 2.5 / d1) {
            v = n1 * (x -= 2.25 / d1) * x + 0.9375;
          } else {
            v = n1 * (x -= 2.625 / d1) * x + 0.984375;
          }

          return b + c * v;
        }

        Easing.easeOutBounce = easeOutBounce;
      })(Easing = exports.Easing || (exports.Easing = {}));
    }, {}],
    6: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Timeline = void 0;

      var Tween_1 = require("./Tween");
      /**
       * タイムライン機能を提供するクラス。
       */


      var Timeline =
      /** @class */
      function () {
        /**
         * Timelineを生成する。
         * @param scene タイムラインを実行する `Scene`
         */
        function Timeline(scene) {
          this._scene = scene;
          this._tweens = [];
          this._tweensCreateQue = [];
          this._fps = this._scene.game.fps;
          this.paused = false;
          scene.onUpdate.add(this._handler, this);
        }
        /**
         * Timelineに紐付いたTweenを生成する。
         * @param target タイムライン処理の対象にするオブジェクト
         * @param option Tweenの生成オプション。省略された場合、 {modified: target.modified, destroyed: target.destroyed} が与えられた時と同様の処理を行う。
         */


        Timeline.prototype.create = function (target, option) {
          var t = new Tween_1.Tween(target, option);

          this._tweensCreateQue.push(t);

          return t;
        };
        /**
         * Timelineに紐付いたTweenを削除する。
         * @param tween 削除するTween。
         */


        Timeline.prototype.remove = function (tween) {
          var index = this._tweens.indexOf(tween);

          var queIndex = this._tweensCreateQue.indexOf(tween);

          if (index < 0 && queIndex < 0) {
            return;
          }

          tween.cancel(false);
        };
        /**
         * Timelineに紐付いた全Tweenのアクションを完了させる。詳細は `Tween#complete()`の説明を参照。
         */


        Timeline.prototype.completeAll = function () {
          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween.complete();
            }
          }

          for (var i = 0; i < this._tweensCreateQue.length; ++i) {
            var tween = this._tweensCreateQue[i];

            if (!tween.isFinished()) {
              tween.complete();
            }
          }
        };
        /**
         * Timelineに紐付いた全Tweenのアクションを取り消す。詳細は `Tween#cancel()`の説明を参照。
         * @param revert ターゲットのプロパティをアクション開始前に戻すかどうか (指定しない場合は `false`)
         */


        Timeline.prototype.cancelAll = function (revert) {
          if (revert === void 0) {
            revert = false;
          }

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween.cancel(revert);
            }
          }

          for (var i = 0; i < this._tweensCreateQue.length; ++i) {
            var tween = this._tweensCreateQue[i];

            if (!tween.isFinished()) {
              tween.cancel(revert);
            }
          }
        };
        /**
         * Timelineに紐付いた全Tweenの紐付けを解除する。
         */


        Timeline.prototype.clear = function () {
          this.cancelAll(false);
        };
        /**
         * このTimelineを破棄する。
         */


        Timeline.prototype.destroy = function () {
          this.clear();

          if (!this._scene.destroyed()) {
            this._scene.onUpdate.remove(this._handler, this);
          }

          this._scene = undefined;
        };
        /**
         * このTimelineが破棄済みであるかを返す。
         */


        Timeline.prototype.destroyed = function () {
          return this._scene === undefined;
        };

        Timeline.prototype._handler = function () {
          if (this.paused || this._tweens.length + this._tweensCreateQue.length === 0) {
            return;
          }

          this._tweens = this._tweens.concat(this._tweensCreateQue);
          this._tweensCreateQue = [];
          var tmp = [];

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.shouldRemove()) {
              tween._fire(1000 / this._fps);

              tmp.push(tween);
            }
          }

          this._tweens = tmp;
        };

        return Timeline;
      }();

      exports.Timeline = Timeline;
    }, {
      "./Tween": 7
    }],
    7: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Tween = void 0;

      var ActionType_1 = require("./ActionType");

      var Easing_1 = require("./Easing");
      /**
       * オブジェクトの状態を変化させるアクションを定義するクラス。
       * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
       */


      var Tween =
      /** @class */
      function () {
        /**
         * Tweenを生成する。
         * @param target 対象となるオブジェクト
         * @param option オプション
         */
        function Tween(target, option) {
          this._target = target;
          this._stepIndex = 0;
          this._loop = !!option && !!option.loop;
          this._stale = false;
          this._modifiedHandler = undefined;

          if (option && option.modified) {
            this._modifiedHandler = option.modified;
          } else if (target && target.modified) {
            this._modifiedHandler = target.modified;
          }

          this._destroyedHandler = undefined;

          if (option && option.destroyed) {
            this._destroyedHandler = option.destroyed;
          } else if (target && target.destroyed) {
            this._destroyedHandler = target.destroyed;
          }

          this._steps = [];
          this._lastStep = undefined;
          this._pararel = false;
          this._initialProp = {};
          this.paused = false;
        }
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.to = function (props, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType_1.ActionType.TweenTo,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * 変化内容はアクション開始時を基準とした相対値で指定する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
         */


        Tween.prototype.by = function (props, duration, easing, multiply) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          if (multiply === void 0) {
            multiply = false;
          }

          var type = multiply ? ActionType_1.ActionType.TweenByMult : ActionType_1.ActionType.TweenBy;
          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
         * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
         */


        Tween.prototype.con = function () {
          this._pararel = true;
          return this;
        };
        /**
         * オブジェクトの変化を停止するアクションを追加する。
         * @param duration 停止する時間（ミリ秒）
         */


        Tween.prototype.wait = function (duration) {
          var action = {
            duration: duration,
            type: ActionType_1.ActionType.Wait,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 関数を即座に実行するアクションを追加する。
         * @param func 実行する関数
         */


        Tween.prototype.call = function (func) {
          var action = {
            func: func,
            type: ActionType_1.ActionType.Call,
            duration: 0,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 一時停止するアクションを追加する。
         * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
         */


        Tween.prototype.pause = function () {
          var _this = this;

          return this.call(function () {
            _this.paused = true;
          });
        };
        /**
         * 待機時間をキーとして実行したい関数を複数指定する。
         * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
         */


        Tween.prototype.cue = function (funcs) {
          var keys = Object.keys(funcs);
          keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
          });
          var q = [];

          for (var i = 0; i < keys.length; ++i) {
            q.push({
              time: Number(keys[i]),
              func: funcs[keys[i]]
            });
          }

          var action = {
            type: ActionType_1.ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
         * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.every = function (func, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          var action = {
            func: func,
            type: ActionType_1.ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * ターゲットをフェードインさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeIn = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.to({
            opacity: 1
          }, duration, easing);
        };
        /**
         * ターゲットをフェードアウトさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeOut = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.to({
            opacity: 0
          }, duration, easing);
        };
        /**
         * ターゲットを指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveTo = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.to({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveBy = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.by({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットのX座標を指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveX = function (x, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.to({
            x: x
          }, duration, easing);
        };
        /**
         * ターゲットのY座標を指定した座標に移動するアクションを追加する。
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveY = function (y, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.to({
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateTo = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.to({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateBy = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.by({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットを指定した倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.to({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing);
        };
        /**
         * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing_1.Easing.linear;
          }

          return this.by({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing, true);
        };
        /**
         * このTweenに追加されたすべてのアクションを即座に完了する。
         * `Tween#loop`が`true`の場合、ループの終端までのアクションがすべて実行される。
         */


        Tween.prototype.complete = function () {
          for (var i = this._stepIndex; i < this._steps.length; ++i) {
            for (var j = 0; j < this._steps[i].length; ++j) {
              var action = this._steps[i][j];

              if (!action.initialized) {
                this._initAction(action);
              }

              var keys = Object.keys(action.goal);

              for (var k = 0; k < keys.length; ++k) {
                var key = keys[k];
                this._target[key] = action.goal[key];
              }

              if (action.type === ActionType_1.ActionType.Call && typeof action.func === "function") {
                action.func.call(this._target);
              } else if (action.type === ActionType_1.ActionType.Cue && action.cue) {
                for (var k = 0; k < action.cue.length; ++k) {
                  action.cue[k].func.call(this._target);
                }
              } else if (action.type === ActionType_1.ActionType.Every && typeof action.func === "function") {
                action.func.call(this._target, action.duration, 1);
              }
            }
          }

          this._stepIndex = this._steps.length;
          this._loop = false;
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;

          if (this._modifiedHandler) {
            this._modifiedHandler.call(this._target);
          }
        };
        /**
         * このTweenに追加されたすべてのアクションを取り消す。
         * `revert`を`true` にした場合、ターゲットのプロパティをアクション開始前に戻す。
         * ただし`Tween#call()`や`Tween#every()`により変更されたプロパティは戻らない点に注意。
         * @param revert ターゲットのプロパティをアクション開始前に戻すかどうか (指定しない場合は `false`)
         */


        Tween.prototype.cancel = function (revert) {
          if (revert === void 0) {
            revert = false;
          }

          if (revert) {
            var keys = Object.keys(this._initialProp);

            for (var i = 0; i < keys.length; ++i) {
              var key = keys[i];
              this._target[key] = this._initialProp[key];
            }
          }

          this._stepIndex = this._steps.length;
          this._loop = false;
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;
          this._stale = true;

          if (this._modifiedHandler) {
            this._modifiedHandler.call(this._target);
          }
        };
        /**
         * アニメーションが終了しているかどうかを返す。
         * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
         */


        Tween.prototype.isFinished = function () {
          var ret = false;

          if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
          }

          if (!ret) {
            ret = this._stepIndex !== 0 && this._stepIndex >= this._steps.length && !this._loop;
          }

          return ret;
        };
        /**
         * アニメーションが削除可能かどうかを返す。
         * 通常、ゲーム開発者がこのメソッドを呼び出す必要はない。
         */


        Tween.prototype.shouldRemove = function () {
          return this._stale || this.isFinished();
        };
        /**
         * アニメーションを実行する。
         * @param delta 前フレームからの経過時間
         */


        Tween.prototype._fire = function (delta) {
          if (this._steps.length === 0 || this.isFinished() || this.paused) {
            return;
          }

          if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
              this._stepIndex = 0;
            } else {
              return;
            }
          }

          var actions = this._steps[this._stepIndex];
          var remained = false;

          for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];

            if (!action.initialized) {
              this._initAction(action);
            }

            if (action.finished) {
              continue;
            }

            action.elapsed += delta;

            switch (action.type) {
              case ActionType_1.ActionType.Call:
                action.func.call(this._target);
                break;

              case ActionType_1.ActionType.Every:
                var progress = action.easing(action.elapsed, 0, 1, action.duration);

                if (progress > 1) {
                  progress = 1;
                }

                action.func.call(this._target, action.elapsed, progress);
                break;

              case ActionType_1.ActionType.TweenTo:
              case ActionType_1.ActionType.TweenBy:
              case ActionType_1.ActionType.TweenByMult:
                var keys = Object.keys(action.goal);

                for (var j = 0; j < keys.length; ++j) {
                  var key = keys[j]; // アクションにより undefined が指定されるケースと初期値を区別するため Object.prototype.hasOwnProperty() を利用
                  // (number以外が指定されるケースは存在しないが念の為)

                  if (!this._initialProp.hasOwnProperty(key)) {
                    this._initialProp[key] = this._target[key];
                  }

                  if (action.elapsed >= action.duration) {
                    this._target[key] = action.goal[key];
                  } else {
                    this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                  }
                }

                break;

              case ActionType_1.ActionType.Cue:
                var cueAction = action.cue[action.cueIndex];

                if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                  cueAction.func.call(this._target);
                  ++action.cueIndex;
                }

                break;
            }

            if (this._modifiedHandler) {
              this._modifiedHandler.call(this._target);
            }

            if (action.elapsed >= action.duration) {
              action.finished = true;
            } else {
              remained = true;
            }
          }

          if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
              actions[k].initialized = false;
            }

            ++this._stepIndex;
          }
        };
        /**
         * Tweenの実行状態をシリアライズして返す。
         */


        Tween.prototype.serializeState = function () {
          var tData = {
            _stepIndex: this._stepIndex,
            _initialProp: this._initialProp,
            _steps: []
          };

          for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];

            for (var j = 0; j < this._steps[i].length; ++j) {
              tData._steps[i][j] = {
                input: this._steps[i][j].input,
                start: this._steps[i][j].start,
                goal: this._steps[i][j].goal,
                duration: this._steps[i][j].duration,
                elapsed: this._steps[i][j].elapsed,
                type: this._steps[i][j].type,
                cueIndex: this._steps[i][j].cueIndex,
                initialized: this._steps[i][j].initialized,
                finished: this._steps[i][j].finished
              };
            }
          }

          return tData;
        };
        /**
         * Tweenの実行状態を復元する。
         * @param serializedstate 復元に使う情報。
         */


        Tween.prototype.deserializeState = function (serializedState) {
          this._stepIndex = serializedState._stepIndex;
          this._initialProp = serializedState._initialProp;

          for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
              if (!serializedState._steps[i][j] || !this._steps[i][j]) continue;
              this._steps[i][j].input = serializedState._steps[i][j].input;
              this._steps[i][j].start = serializedState._steps[i][j].start;
              this._steps[i][j].goal = serializedState._steps[i][j].goal;
              this._steps[i][j].duration = serializedState._steps[i][j].duration;
              this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
              this._steps[i][j].type = serializedState._steps[i][j].type;
              this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
              this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
              this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
          }
        };
        /**
         * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
         * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
         */


        Tween.prototype._push = function (action) {
          if (this._pararel) {
            this._lastStep.push(action);
          } else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
          }

          this._pararel = false;
        };

        Tween.prototype._initAction = function (action) {
          action.elapsed = 0;
          action.start = {};
          action.goal = {};
          action.cueIndex = 0;
          action.finished = false;
          action.initialized = true;

          if (action.type !== ActionType_1.ActionType.TweenTo && action.type !== ActionType_1.ActionType.TweenBy && action.type !== ActionType_1.ActionType.TweenByMult) {
            return;
          }

          var keys = Object.keys(action.input);

          for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];

            if (this._target[key] !== undefined) {
              action.start[key] = this._target[key];

              if (action.type === ActionType_1.ActionType.TweenTo) {
                action.goal[key] = action.input[key];
              } else if (action.type === ActionType_1.ActionType.TweenBy) {
                action.goal[key] = action.start[key] + action.input[key];
              } else if (action.type === ActionType_1.ActionType.TweenByMult) {
                action.goal[key] = action.start[key] * action.input[key];
              }
            }
          }
        };

        return Tween;
      }();

      exports.Tween = Tween;
    }, {
      "./ActionType": 4,
      "./Easing": 5
    }],
    8: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Easing = exports.Tween = exports.Timeline = void 0;

      var Timeline_1 = require("./Timeline");

      Object.defineProperty(exports, "Timeline", {
        enumerable: true,
        get: function get() {
          return Timeline_1.Timeline;
        }
      });

      var Tween_1 = require("./Tween");

      Object.defineProperty(exports, "Tween", {
        enumerable: true,
        get: function get() {
          return Tween_1.Tween;
        }
      });

      var Easing_1 = require("./Easing");

      Object.defineProperty(exports, "Easing", {
        enumerable: true,
        get: function get() {
          return Easing_1.Easing;
        }
      });
    }, {
      "./Easing": 5,
      "./Timeline": 6,
      "./Tween": 7
    }],
    9: [function (require, module, exports) {
      "use strict";

      var __assign = this && this.__assign || function () {
        __assign = Object.assign || function (t) {
          for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];

            for (var p in s) {
              if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
          }

          return t;
        };

        return __assign.apply(this, arguments);
      };

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.FallbackDialog = void 0;

      var akashic_hover_plugin_1 = require("@akashic-extension/akashic-hover-plugin");

      var HoverPluginRaw = require("@akashic-extension/akashic-hover-plugin/lib/HoverPlugin"); // Ugh! HoverPlugin が Akashic Engine 向けに中途半端に CommonJS で (module.exports = HoverPlugin と)
      // 定義されている関係で、 import すると TS の型と実体が合わない。無理やり解消する。
      // (import * as ... すると、 JS 的には HoverPlugin の実体が手に入るが、TS 上では namespace と誤認される)
      // さらにおそらく akashic-hover-plugin 側のバグで、型があっていないのでそれも無理やり合わせる。
      // (コンストラクタ第二引数が間違っている。実装上は any キャストして正しく使っている)


      var HoverPlugin = HoverPluginRaw;

      function drawCircle(rendr, centerX, centerY, radius, cssColor) {
        for (var y = centerY - radius | 0; y <= Math.ceil(centerY + radius); ++y) {
          var w = radius * Math.cos(Math.asin((centerY - y) / radius));
          rendr.fillRect(centerX - w, y, 2 * w, 1, cssColor);
        }
      }

      function makeSurface(w, h, drawer) {
        var s = g.game.resourceFactory.createSurface(Math.ceil(w), Math.ceil(h));
        var r = s.renderer();
        r.begin();
        drawer(r);
        r.end();
        return s;
      }

      function animate(e, motions) {
        var onEnd = new g.Trigger();
        var frameTime = 1000 / g.game.fps;
        var step = 0;
        var time = 0;
        var mot = motions[0];
        var ended = false;

        function update(delta) {
          time += delta;

          if (time > mot.duration) {
            ended = ++step >= motions.length;

            if (ended) {
              time = mot.duration;
              e.scene.onUpdate.addOnce(onEnd.fire, onEnd);
            } else {
              time -= mot.duration;
              mot = motions[step];
            }
          }

          var r = Math.min(1, time / mot.duration);
          var scale = mot.scale,
              opacity = mot.opacity;
          if (scale) e.scaleX = e.scaleY = scale[0] + (scale[1] - scale[0]) * r;
          if (opacity) e.opacity = opacity[0] + (opacity[1] - opacity[0]) * r;
          e.modified();
          return ended;
        }

        update(0);
        e.onUpdate.add(function () {
          return update(frameTime);
        });
        return onEnd;
      }

      var FallbackDialog =
      /** @class */
      function () {
        function FallbackDialog(name) {
          var _this = this;

          this.onEnd = new g.Trigger();
          this.isHoverPluginStarted = false;
          this.timer = null;
          if (!FallbackDialog.isSupported()) return;
          var game = g.game;
          var gameWidth = game.width,
              gameHeight = game.height;
          var baseWidth = 1280;
          var ratio = gameWidth / baseWidth;
          var titleFontSize = Math.round(32 * ratio);
          var fontSize = Math.round(28 * ratio);
          var lineMarginRate = 0.3;
          var lineHeightRate = 1 + lineMarginRate;
          var titleTopMargin = 80 * ratio;
          var titleBotMargin = 32 * ratio;
          var buttonTopMargin = 42 * ratio;
          var buttonWidth = 360 * ratio;
          var buttonHeight = 82 * ratio;
          var buttonBotMargin = 72 * ratio;
          var colorBlue = "#4a8de1";
          var colorWhite = "#fff";
          var dialogWidth = 960 * ratio | 0;
          var dialogHeight = titleTopMargin + titleFontSize * lineHeightRate * 2 + titleBotMargin + (fontSize + fontSize * lineHeightRate) + // 一行目のマージンは titleBotMargin に繰り込まれている
          buttonTopMargin + buttonHeight + buttonBotMargin | 0;
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: g.FontFamily.SansSerif,
            size: titleFontSize,
            fontWeight: g.FontWeight.Bold,
            fontColor: "#252525"
          });
          var surfSize = Math.ceil(32 * ratio) & ~1; // 切り上げて偶数に丸める

          var surfHalf = surfSize / 2;
          var dialogBgSurf = makeSurface(surfSize, surfSize, function (r) {
            return drawCircle(r, surfHalf, surfHalf, surfHalf, colorWhite);
          });
          var btnActiveBgSurf = makeSurface(surfSize, surfSize, function (r) {
            return drawCircle(r, surfHalf, surfHalf, surfHalf, colorBlue);
          });
          var btnBgSurf = makeSurface(surfSize, surfSize, function (r) {
            drawCircle(r, surfHalf, surfHalf, surfHalf, colorBlue);
            drawCircle(r, surfHalf, surfHalf, 12 * ratio, colorWhite);
          });

          function makeLabel(param) {
            return new g.Label(__assign({
              scene: scene,
              font: font,
              local: true,
              textAlign: g.TextAlign.Center,
              widthAutoAdjust: false
            }, param));
          }

          var scene = this.scene = game.scene();
          var bg = this.bgRect = new g.FilledRect({
            scene: scene,
            local: true,
            width: gameWidth,
            height: gameHeight,
            cssColor: "rgba(0, 0, 0, 0.5)",
            touchable: true // 後ろの touch を奪って modal にする

          });
          var dialogPane = this.dialogPane = new g.Pane({
            scene: scene,
            local: true,
            width: dialogWidth,
            height: dialogHeight,
            anchorX: 0.5,
            anchorY: 0.5,
            x: game.width / 2 | 0,
            y: game.height / 2 | 0,
            backgroundImage: dialogBgSurf,
            backgroundEffector: new g.NinePatchSurfaceEffector(game, dialogBgSurf.width / 2 - 1),
            parent: bg
          });
          var dialogTextX = 80 * ratio | 0;
          var dialogTextWidth = 800 * ratio | 0;
          var y = 0;
          y += titleTopMargin + titleFontSize * lineMarginRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "このコンテンツは名前を利用します。",
            fontSize: titleFontSize,
            width: dialogTextWidth
          }));
          y += titleFontSize * lineHeightRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "\u3042\u306A\u305F\u306F\u300C" + name + "\u300D\u3067\u3059\u3002",
            fontSize: titleFontSize,
            width: dialogTextWidth
          }));
          y += titleFontSize + titleBotMargin | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "ユーザ名で参加するには、",
            fontSize: fontSize,
            width: dialogTextWidth
          }));
          y += fontSize * lineHeightRate | 0;
          dialogPane.append(makeLabel({
            x: dialogTextX,
            y: y,
            text: "最新のニコニコ生放送アプリに更新してください。",
            fontSize: fontSize,
            width: dialogTextWidth
          }));
          y += fontSize + buttonTopMargin | 0;
          var buttonPane = new g.Pane({
            scene: scene,
            local: true,
            width: buttonWidth,
            height: buttonHeight,
            x: dialogWidth / 2,
            y: y + buttonHeight / 2,
            anchorX: 0.5,
            anchorY: 0.5,
            backgroundImage: btnBgSurf,
            backgroundEffector: new g.NinePatchSurfaceEffector(game, btnBgSurf.width / 2 - 1),
            parent: scene,
            touchable: true
          });
          dialogPane.append(buttonPane);
          var buttonLabel = this.buttonLabel = makeLabel({
            x: 0,
            y: (buttonHeight - titleFontSize) / 2 - 5 * ratio,
            text: "OK (15)",
            fontSize: titleFontSize,
            width: buttonWidth,
            textColor: colorBlue
          });
          buttonPane.append(buttonLabel);

          var activateButton = function activateButton() {
            buttonPane.backgroundImage = btnActiveBgSurf;
            buttonPane.invalidate();
            buttonLabel.textColor = colorWhite;
            buttonLabel.invalidate();
          };

          var deactivateButton = function deactivateButton() {
            buttonPane.backgroundImage = btnBgSurf;
            buttonPane.invalidate();
            buttonLabel.textColor = colorBlue;
            buttonLabel.invalidate();
          };

          var h = akashic_hover_plugin_1.Converter.asHoverable(buttonPane);
          var animating = false;
          h.hovered.add(function () {
            activateButton();
            if (animating) return;
            animating = true;
            animate(buttonPane, [{
              duration: 16,
              scale: [1.0, 0.9]
            }, {
              duration: 16,
              scale: [0.9, 1.1]
            }, {
              duration: 33,
              scale: [1.1, 1.0]
            }]).add(function () {
              return animating = false;
            });
          });
          h.unhovered.add(deactivateButton);
          buttonPane.onPointDown.add(activateButton);
          buttonPane.onPointUp.add(function () {
            _this.end();
          });
          if (!game.operationPluginManager.plugins[FallbackDialog.HOVER_PLUGIN_OPCODE]) game.operationPluginManager.register(HoverPlugin, FallbackDialog.HOVER_PLUGIN_OPCODE);
        }

        FallbackDialog.isSupported = function () {
          // 縦横比 0.4 について: このダイアログは 16:9 の解像度で画面高さの約 65% (468px) を占有する。
          // すなわち画面高さが画面幅の約 37% 以下の場合画面に収まらない。余裕を見て 40% を下限とする。
          // (詳細な高さは下の dialogHeight の定義を参照せよ)
          return typeof window !== "undefined" && g.game.height / g.game.width >= 0.4 && HoverPlugin.isSupported();
        };

        FallbackDialog.prototype.start = function (remainingSeconds) {
          var _this = this;

          var game = g.game;
          var scene = this.scene;

          if (game.scene() !== scene) {
            // ないはずの異常系だが一応確認
            return;
          } // エッジケース考慮: hoverプラグインは必ず停止したいので、シーンが変わった時点で止めてしまう。
          // (mouseover契機で無駄にエンティティ検索したくない)


          game.onSceneChange.add(this._disablePluginOnSceneChange, this);
          game.operationPluginManager.start(FallbackDialog.HOVER_PLUGIN_OPCODE);
          this.isHoverPluginStarted = true;
          animate(this.dialogPane, [{
            duration: 100,
            scale: [0.5, 1.1],
            opacity: [0.5, 1.0]
          }, {
            duration: 100,
            scale: [1.1, 1.0],
            opacity: [1.0, 1.0]
          }]);
          scene.append(this.bgRect);
          scene.onUpdate.add(this._assureFrontmost, this);
          this.timer = scene.setInterval(function () {
            remainingSeconds -= 1;
            _this.buttonLabel.text = "OK (" + remainingSeconds + ")";

            _this.buttonLabel.invalidate();

            if (remainingSeconds <= 0) {
              _this.end();
            }
          }, 1000);
        };

        FallbackDialog.prototype.end = function () {
          var _this = this;

          if (this.timer) {
            this.scene.clearInterval(this.timer);
            this.timer = null;
          } // 厳密には下のアニメーション終了後に解除する方がよいが、
          // 途中でシーンが破棄されるエッジケースを想定してこの時点で止める。


          this.scene.onUpdate.remove(this._assureFrontmost, this);

          if (this.isHoverPluginStarted) {
            g.game.operationPluginManager.stop(FallbackDialog.HOVER_PLUGIN_OPCODE);
            this.isHoverPluginStarted = false;
          }

          animate(this.dialogPane, [{
            duration: 100,
            opacity: [1, 0],
            scale: [1, 0.8]
          }]);
          var t = animate(this.bgRect, [{
            duration: 100,
            opacity: [1, 0]
          }]);
          t.add(function () {
            var onEnd = _this.onEnd;
            _this.onEnd = null;

            _this.bgRect.destroy();

            _this.bgRect = null;
            _this.dialogPane = null;
            _this.scene = null;
            onEnd.fire();
          });
        };

        FallbackDialog.prototype._disablePluginOnSceneChange = function (scene) {
          if (scene !== this.scene) {
            g.game.operationPluginManager.stop(FallbackDialog.HOVER_PLUGIN_OPCODE);
            return true;
          }
        }; // フレーム終了時に確実に画面最前面に持ってくる


        FallbackDialog.prototype._assureFrontmost = function () {
          g.game._pushPostTickTask(this._doAssureFrontmost, this);
        };

        FallbackDialog.prototype._doAssureFrontmost = function () {
          var scene = this.scene;
          if (scene && g.game.scene() !== scene) return;
          if (scene.children[scene.children.length - 1] === this.bgRect) return;
          this.bgRect.remove();
          scene.append(this.bgRect);
        };

        FallbackDialog.HOVER_PLUGIN_OPCODE = -1000; // TODO: 定数予約

        return FallbackDialog;
      }();

      exports.FallbackDialog = FallbackDialog;
    }, {
      "@akashic-extension/akashic-hover-plugin": 3,
      "@akashic-extension/akashic-hover-plugin/lib/HoverPlugin": 2
    }],
    10: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.resolvePlayerInfo = void 0;

      var FallbackDialog_1 = require("./FallbackDialog");

      var rpgAtsumaru = typeof window !== "undefined" ? window.RPGAtsumaru : undefined;

      function createRandomName() {
        return "ゲスト" + (Math.random() * 1000 | 0);
      }

      var resolvers = [// window.RPGAtsumaru
      {
        isSupported: function isSupported() {
          return !!(rpgAtsumaru && rpgAtsumaru.user && rpgAtsumaru.user.getSelfInformation);
        },
        resolve: function resolve(_limitSeconds, callback) {
          rpgAtsumaru.user.getSelfInformation().then(function (selfInfo) {
            callback(null, {
              name: selfInfo.name,
              userData: {
                accepted: true,
                premium: selfInfo.isPremium
              }
            });
          }, function (err) {
            callback(err, null);
          });
        }
      }, // coeLimited
      {
        isSupported: function isSupported() {
          var coeLimited = g.game.external.coeLimited;
          return !!(coeLimited && coeLimited.startLocalSession && coeLimited.exitLocalSession);
        },
        resolve: function resolve(limitSeconds, callback) {
          var sessionId = g.game.playId + "__player-info-resolver";
          var scene = g.game.scene();
          var timeoutId = scene.setTimeout(function () {
            timeoutId = null; // NOTE: スキップ時は既に終了済みのローカルセッション自体が起動せず messageHandler() も呼ばれなるため、
            // ここで callback() を呼ばないとコンテンツ側がコールバックをいつまでも待ってしまう状態になってしまう

            callback(null, {
              name: null,
              userData: {
                accepted: false,
                premium: false
              }
            }); // NOTE: リアルタイム視聴の場合、大半のケースではこちらのパスには到達しないはず
            // (仮に到達しても同一セッションIDの COE#exitSession() が呼ばれるのみ)
            // 追っかけ再生またはタイムシフトによる視聴においては、
            // player-info-resolver の自発終了よりも先に以下の exitLocalSession() を呼ぶことで
            // 「スキップ中のセッション起動を抑止する」というプラットフォーム側の機能を有効にしている

            g.game.external.coeLimited.exitLocalSession(sessionId, {
              needsResult: true
            });
          }, (limitSeconds + 2) * 1000); // NOTE: 読み込みなどを考慮して 2 秒のバッファを取る

          g.game.external.coeLimited.startLocalSession({
            sessionId: sessionId,
            applicationName: "player-info-resolver",
            localEvents: [[32, 0, ":akashic", {
              type: "start",
              parameters: {
                limitSeconds: limitSeconds
              }
            }]],
            messageHandler: function messageHandler(message) {
              if (timeoutId == null) {
                // 先にタイムアウト処理が実行されていたら何もしない
                return;
              }

              scene.clearTimeout(timeoutId); // TODO 引数からエラーを取得できるようになったら、異常系の処理も行う

              callback(null, message.result);
            }
          });
        }
      }, // g.game.external.atsumaru
      {
        isSupported: function isSupported() {
          var atsumaru = g.game.external.atsumaru;
          return !!(atsumaru && atsumaru.getSelfInformationProto);
        },
        resolve: function resolve(_limitSeconds, _callback) {
          g.game.external.atsumaru.getSelfInformationProto({
            callback: function callback(errorMessage, result) {
              if (errorMessage != null) {
                _callback(new Error(errorMessage), null);

                return;
              }

              if (result && result.login) {
                _callback(null, {
                  name: result.name,
                  userData: {
                    accepted: true,
                    premium: result.premium
                  }
                });
              } else {
                _callback(null, {
                  name: createRandomName(),
                  userData: {
                    accepted: false,
                    premium: false
                  }
                });
              }
            }
          });
        }
      }, // FallbackDialog
      {
        isSupported: FallbackDialog_1.FallbackDialog.isSupported,
        resolve: function resolve(limitSeconds, callback) {
          var name = createRandomName();
          var dialog = new FallbackDialog_1.FallbackDialog(name);
          dialog.start(limitSeconds);
          dialog.onEnd.addOnce(function () {
            callback(null, {
              name: name,
              userData: {
                accepted: false,
                premium: false
              }
            });
          });
        }
      }, // sentinel
      {
        isSupported: function isSupported() {
          return true;
        },
        resolve: function resolve(_limitSeconds, callback) {
          callback(null, {
            name: "",
            userData: {
              accepted: false,
              premium: false,
              unnamed: true
            }
          });
        }
      }];
      var DEFAULT_LIMIT_SECONDS = 15; // resolvePlayerInfo() の多重呼び出し防止フラグ

      var isResolving = false;

      function find(xs, pred) {
        for (var i = 0; i < xs.length; ++i) {
          if (pred(xs[i])) return xs[i];
        }

        return undefined;
      }
      /**
       * ユーザー情報の取得と通知を行う
       * @param opts ユーザ情報取得時のオプション
       * @param callback 指定された場合、playerInfo が取得成功・失敗した時点の次の local/non-local tick で呼び出される
       */


      exports.resolvePlayerInfo = function (opts, callback) {
        if (isResolving) {
          callback === null || callback === void 0 ? void 0 : callback(new Error("Last processing has not yet been completed."), null);
          return;
        }

        var cb = function cb(err, info) {
          isResolving = false;
          callback === null || callback === void 0 ? void 0 : callback(err, info);

          if (!err) {
            var _a = info,
                name_1 = _a.name,
                userData = _a.userData;

            if (opts && opts.raises && (!userData || !userData.unnamed)) {
              g.game.raiseEvent(new g.PlayerInfoEvent({
                id: g.game.selfId,
                name: name_1,
                userData: userData
              }));
            }
          }
        };

        var limitSeconds = opts && opts.limitSeconds ? opts.limitSeconds : DEFAULT_LIMIT_SECONDS;
        var resolver = find(resolvers, function (r) {
          return r.isSupported();
        }); // isSupported() が恒真の実装があるので non-null

        try {
          isResolving = true;
          resolver.resolve(limitSeconds, cb);
        } catch (e) {
          cb(e);
        }
      };
    }, {
      "./FallbackDialog": 9
    }],
    11: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics = function extendStatics(d, b) {
          _extendStatics = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
            }
          };

          return _extendStatics(d, b);
        };

        return function (d, b) {
          if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

          _extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.MainGame = void 0;

      var Player_1 = require("./Player");

      var tl = require("@akashic-extension/akashic-timeline"); //ゲームのメイン


      var MainGame =
      /** @class */
      function (_super) {
        __extends(MainGame, _super);

        function MainGame() {
          var _this = this;

          var scene = g.game.scene();
          _this = _super.call(this, {
            scene: scene,
            width: g.game.width,
            height: g.game.height,
            touchable: true
          }) || this;

          _this.init = function (pid) {};

          _this.colors = ["#ff5050", "green", "yellow", "blue"];
          var players = {};
          var gameState = "start"; // マップの親(スケールのxとyを伸縮させて疑似的に奥行きを表現)

          var mapBase = new g.E({
            scene: scene,
            x: g.game.width / 2,
            y: g.game.height / 2 + 250,
            width: 0,
            height: 0,
            anchorX: 0,
            anchorY: 0,
            scaleY: 0.8,
            scaleX: 5.0,
            parent: _this
          }); //床

          var floor = new g.FilledRect({
            scene: scene,
            x: 0,
            y: 0,
            width: 2000,
            height: 2000,
            anchorX: 0.5,
            anchorY: 0.5,
            angle: 0,
            cssColor: "gray",
            parent: mapBase
          }); //マップチップ

          var maps = [];

          for (var y = 0; y < 20; y++) {
            maps[y] = [];

            for (var x = 0; x < 20; x++) {
              maps[y].push(new g.FilledRect({
                scene: scene,
                x: x * 100,
                y: y * 100,
                width: 100 - 2,
                height: 100 - 2,
                cssColor: "white",
                parent: floor,
                tag: -1
              }));
            }
          } // ユニット配置用


          var unitBase = new g.E({
            scene: scene,
            parent: _this
          });
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: "sans-serif",
            size: 50
          }); // 上で生成した font.png と font_glyphs.json に対応するアセットを取得

          var fontAsset = g.game.scene().asset.getImageById("number");
          var fontGlyphAsset = g.game.scene().asset.getTextById("glyph"); // テキストアセット (JSON) の内容をオブジェクトに変換

          var glyphInfo = JSON.parse(fontGlyphAsset.data); // ビットマップフォントを生成

          var fontNum = new g.BitmapFont({
            src: fontAsset,
            glyphInfo: glyphInfo
          }); //残り時間表示

          new g.Sprite({
            scene: scene,
            src: g.game.scene().asset.getImageById("time"),
            x: 500,
            y: 25,
            parent: _this
          });
          var timeLimit = 90;
          var labelTime = new g.Label({
            scene: scene,
            x: 600,
            y: 30,
            font: fontNum,
            text: "90",
            parent: _this
          }); //マップの色ごとの数表示用

          var numColor = 4;
          var rankBases = [];
          var labelColors = [];
          var rectRanks = [];

          for (var i = 0; i < numColor; i++) {
            var rankBase = new g.E({
              scene: scene,
              x: 1100,
              y: 150 * i + 50,
              width: 80,
              height: 80,
              parent: _this
            });
            rankBases.push(rankBase);
            new g.Label({
              scene: scene,
              x: -50,
              y: 10,
              font: fontNum,
              text: "" + (i + 1),
              parent: rankBase
            });
            var rect = new g.FilledRect({
              scene: scene,
              x: 1100,
              y: 150 * i + 50,
              width: 170,
              height: 80,
              cssColor: _this.colors[i],
              parent: _this
            });
            rectRanks.push(rect);
            labelColors.push(new g.Label({
              scene: scene,
              x: 0,
              y: 10,
              width: 170,
              font: fontNum,
              textAlign: "right",
              widthAutoAdjust: false,
              text: "0",
              parent: rect
            }));
          } //スタート表示用


          var startBase = new g.E({
            scene: scene,
            parent: _this
          });
          var rectStart = new g.FilledRect({
            scene: scene,
            width: g.game.width,
            height: g.game.height,
            cssColor: "black",
            opacity: 0.5,
            parent: startBase
          });
          var sprStart = new g.FrameSprite({
            scene: scene,
            src: scene.asset.getImageById("start"),
            x: (g.game.width - 800) / 2,
            y: (g.game.height - 250) / 2,
            width: 800,
            height: 250,
            frameNumber: 0,
            frames: [0, 1],
            parent: startBase
          }); // デバッグ用文字列

          var debugText = new g.Label({
            scene: scene,
            y: g.game.height - 50,
            font: font,
            text: "",
            textColor: "red",
            parent: _this
          });
          var timeline = new tl.Timeline(scene);
          floor.onUpdate.add(function () {// floor.angle += 0.3;
            // floor.modified();
          }); //キーイベントを受け取る

          _this.onMessage.add(function (msg) {
            if (gameState != "play") return; // 関係ないイベントは無視して抜ける

            if (!msg.data) return;
            var ev = msg.data; //矢印キーを押したとき

            if (ev.key) {
              var player = players[msg.player.id];
              if (!player) return;

              if (ev.isPush) {
                // 移動速度を設定
                if (ev.key == "ArrowUp") {
                  player.speed = 10;
                }

                if (ev.key == "ArrowDown") {
                  player.speed = -10;
                }

                if (ev.key == "ArrowRight") {
                  player.rotate = 2;
                }

                if (ev.key == "ArrowLeft") {
                  player.rotate = -2;
                }
              } else {
                // 移動速度を0にする
                if (ev.key == "ArrowUp") {
                  player.speed = 0;
                }

                if (ev.key == "ArrowDown") {
                  player.speed = 0;
                }

                if (ev.key == "ArrowRight") {
                  player.rotate = 0;
                }

                if (ev.key == "ArrowLeft") {
                  player.rotate = 0;
                } // if (ev.key == "a" || ev.key == "A") {
                // 	player.setColor();
                // }

              }
            }
          });

          _this.onPointMove.add(function (ev) {
            if (gameState != "play") return;
            var player = players[ev.player.id];

            if (player) {
              var px = ev.point.x + ev.startDelta.x;
              var py = ev.point.y + ev.startDelta.y;

              if (py < _this.height / 3 * 2) {
                player.speed = 10;
              } else {
                player.speed = -10;
              }

              if (px < _this.width / 3) {
                player.rotate = -2;
              } else if (px > _this.width / 3 * 2) {
                player.rotate = 2;
              } else {
                player.rotate = 0;
              }
            }
          });

          _this.onPointUp.add(function (ev) {
            if (gameState != "play") return;
            var player = players[ev.player.id];

            if (player) {
              player.speed = 0;
              player.rotate = 0;
            }
          });

          var move = function move() {
            var _a; //移動


            for (var key in players) {
              var player_1 = players[key];
              player_1.move(); //床を塗る

              if (player_1.speed != 0) {
                var mx = Math.floor(player_1.base.x / 100);
                var my = Math.floor(player_1.base.y / 100);
                var map = maps[my][mx];

                if (map.tag != player_1.numColor) {
                  map.cssColor = _this.colors[player_1.numColor];
                  map.modified();
                  map.tag = player_1.numColor;

                  if (g.game.selfId == key) {
                    scene.asset.getAudioById("se_move").play().changeVolume(0.2);
                  }
                }
              }
            } //視点移動


            var player = players[g.game.selfId];
            if (!player) player = players[g.game.vars.gameMasterId];
            floor.anchorX = player.base.x / floor.width;
            floor.anchorY = player.base.y / floor.height;
            floor.angle = -player.angle - 90;
            floor.modified();

            if (player.speed > 0) {
              if (player.rotate == 0) {
                player.unit.frameNumber = 4;
              } else if (player.rotate > 0) {
                player.unit.frameNumber = 5;
              } else if (player.rotate < 0) {
                player.unit.frameNumber = 3;
              }
            } else if (player.speed < 0) {
              if (player.rotate == 0) {
                player.unit.frameNumber = 0;
              } else if (player.rotate > 0) {
                player.unit.frameNumber = 7;
              } else if (player.rotate < 0) {
                player.unit.frameNumber = 1;
              }
            }

            player.unit.modified(); //重ね順ソート

            (_a = unitBase.children) === null || _a === void 0 ? void 0 : _a.sort(function (a, b) {
              return a.y - b.y;
            });
          };

          _this.onUpdate.add(function () {
            if (gameState != "play") return; //残り時間を更新

            timeLimit -= 1 / 30;
            labelTime.text = "" + Math.max(0, Math.floor(timeLimit));
            labelTime.invalidate();

            if (0 >= Math.ceil(timeLimit)) {
              finish();
            }

            move(); //マップの色数を数える

            var colorCnt = [0, 0, 0, 0, 0];

            for (var y = 0; y < maps.length; y++) {
              for (var x = 0; x < maps[y].length; x++) {
                if (maps[y][x].tag != -1) {
                  colorCnt[maps[y][x].tag]++;
                }
              }
            } //表示


            for (var i = 0; i < numColor; i++) {
              labelColors[i].text = "" + colorCnt[i];
              labelColors[i].invalidate();
            } //並べ替え


            var index = [0, 1, 2, 3];
            index.sort(function (a, b) {
              return colorCnt[b] - colorCnt[a];
            });

            for (var i = 0; i < index.length; i++) {
              var x = rankBases[index[i]].x;
              var y = rankBases[index[i]].y;
              rectRanks[i].x = x;
              rectRanks[i].y = y;
              rectRanks[i].modified();
            }
          }); //終了処理


          var finish = function finish() {
            gameState = "finish";
            scene.append(startBase);
            sprStart.frameNumber = 1;
            sprStart.modified();
            scene.asset.getAudioById("se_timeup").play();
            scene.setTimeout(function () {
              startBase.hide();
              scene.append(floor);
              var s = (g.game.height - 100) / floor.height;
              floor.scale(s);
              floor.x = 300;
              floor.y = 50;
              floor.anchorX = 0;
              floor.anchorY = 0;
              floor.angle = 0;
              floor.modified();

              for (var key in players) {
                var p = players[key];
                p.unit.hide();
              }
            }, 3000);
          }; //初期化


          _this.init = function (playerIds) {
            for (var i = 0; i < playerIds.length; i++) {
              var player = new Player_1.Player(floor, unitBase, i, playerIds[i].name);
              player.numColor = i % numColor;
              players[playerIds[i].id] = player;
            }

            move();
            scene.asset.getAudioById("se_start").play();
            scene.setTimeout(function () {
              startBase.remove();
              gameState = "play";
            }, 2000);
          };

          return _this;
        }

        return MainGame;
      }(g.E);

      exports.MainGame = MainGame;
    }, {
      "./Player": 12,
      "@akashic-extension/akashic-timeline": 8
    }],
    12: [function (require, module, exports) {
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Player = void 0; //プレイヤークラス

      var Player =
      /** @class */
      function () {
        function Player(rectFloor, rectMain, num, name) {
          this.rectFloor = rectFloor;
          this.rectMain = rectMain;
          this.speed = 0;
          this.rotate = 0; //回転速度

          this.angle = 45; //角度

          this.numColor = 0;

          if (!Player.font) {
            Player.font = new g.DynamicFont({
              game: g.game,
              fontFamily: "sans-serif",
              size: 25
            });
          }

          this.base = new g.FilledRect({
            scene: g.game.scene(),
            x: rectFloor.width / 2 + num * 30,
            y: rectFloor.height / 2,
            width: 50,
            height: 50,
            anchorX: 0.5,
            anchorY: 0.5,
            cssColor: "black",
            opacity: 0.2,
            parent: this.rectFloor
          });
          this.unit = new g.FrameSprite({
            scene: g.game.scene(),
            width: 187.5,
            height: 250,
            anchorX: 0.5,
            anchorY: 0.85,
            scaleX: 1.3,
            scaleY: 1.3,
            src: g.game.scene().asset.getImageById("kaeru"),
            frames: [0, 1, 2, 3, 4, 5, 6, 7, 8],
            parent: this.rectMain
          });
          new g.Label({
            scene: g.game.scene(),
            x: this.unit.width / 2,
            width: 500,
            anchorX: 0.5,
            anchorY: 0.5,
            font: Player.font,
            fontSize: 25,
            textAlign: "center",
            widthAutoAdjust: false,
            text: name,
            parent: this.unit
          });
        }

        Player.prototype.move = function () {
          if (this.speed >= 0) {
            this.angle += this.rotate;
          } else {
            this.angle -= this.rotate;
          }

          var moveX = this.speed * Math.cos(this.angle * (Math.PI / 180));
          var moveY = this.speed * Math.sin(this.angle * (Math.PI / 180));
          this.base.x += moveX;
          this.base.y += moveY;
          this.base.x = Math.max(5, Math.min(this.base.x, this.rectFloor.width - 5));
          this.base.y = Math.max(5, Math.min(this.base.y, this.rectFloor.height - 5));
          this.base.modified(); //カエルの位置を変更し表示

          var gp = this.rectFloor.localToGlobal(this.base);
          this.unit.x = gp.x;
          this.unit.y = gp.y;
          this.unit.modified();
        };

        Player.prototype.setColor = function () {
          this.numColor = (this.numColor + 1) % 4; //this.unit.cssColor = this.colors[this.numColor];
          //this.unit.modified();
        };

        return Player;
      }();

      exports.Player = Player;
    }, {}],
    13: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics2 = function extendStatics(d, b) {
          _extendStatics2 = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
            }
          };

          return _extendStatics2(d, b);
        };

        return function (d, b) {
          if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

          _extendStatics2(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Title = void 0;

      var resolve_player_info_1 = require("@akashic-extension/resolve-player-info"); //参加待ち画面


      var Title =
      /** @class */
      function (_super) {
        __extends(Title, _super);

        function Title() {
          var _this = this;

          var scene = g.game.scene();
          _this = _super.call(this, {
            scene: scene,
            parent: scene
          }) || this;

          _this.start = function () {};

          var playerIds = [];
          var title = new g.Sprite({
            scene: scene,
            x: 123,
            width: 1034,
            height: 720,
            src: scene.asset.getImageById("title"),
            parent: _this
          });
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: "sans-serif",
            size: 50
          });
          var label = new g.Label({
            scene: scene,
            font: font,
            text: "キーボード　↑:前進　↓:後退　←→:回転",
            fontSize: 30,
            textColor: "yellow",
            parent: _this
          });
          new g.Label({
            scene: scene,
            x: 40,
            y: 180,
            font: font,
            text: "カエルトゥーン",
            fontSize: 80,
            textColor: "white",
            parent: title
          });
          var players = {}; // 参加ボタン

          var button = new g.FilledRect({
            scene: scene,
            x: 100,
            y: 400,
            width: 200,
            height: 80,
            cssColor: "white",
            parent: title,
            touchable: true,
            local: true
          });
          var labelButton = new g.Label({
            scene: scene,
            font: font,
            y: 10,
            width: 200,
            text: "参加",
            fontSize: 50,
            textColor: "black",
            textAlign: "center",
            widthAutoAdjust: false,
            parent: button
          }); // 開始ボタン

          var buttonStart = new g.FilledRect({
            scene: scene,
            x: 350,
            y: 400,
            width: 200,
            height: 80,
            cssColor: "white",
            parent: title,
            touchable: true,
            local: true
          });
          buttonStart.hide();
          new g.Label({
            scene: scene,
            font: font,
            y: 10,
            width: 200,
            text: "開始",
            fontSize: 50,
            textColor: "black",
            textAlign: "center",
            widthAutoAdjust: false,
            parent: buttonStart
          }); // 参加人数表示

          var labelCount = new g.Label({
            scene: scene,
            font: font,
            y: -60,
            width: 200,
            text: "0人",
            fontSize: 50,
            textColor: "white",
            textAlign: "center",
            widthAutoAdjust: false,
            parent: button
          }); //ユーザーネーム取得ダイアログからの操作

          g.game.onPlayerInfo.add(function (ev) {
            playerIds.push(ev.player);
            labelCount.text = playerIds.length + "人";
            labelCount.invalidate();
          }); // 参加

          button.onPointDown.add(function (e) {
            (0, resolve_player_info_1.resolvePlayerInfo)({
              raises: true
            });
            button.touchable = false;
            labelButton.text = "参加済み";
            labelButton.invalidate(); //キーボードイベント設定

            document.addEventListener("keydown", function (ev) {
              ev.preventDefault();
              g.game.raiseEvent(new g.MessageEvent({
                isPush: true,
                key: ev.key
              }));
            });
            document.addEventListener("keyup", function (ev) {
              ev.preventDefault();
              g.game.raiseEvent(new g.MessageEvent({
                isPush: false,
                key: ev.key
              }));
            });
            focus(); //フォーカス
          }); // 開始

          buttonStart.onPointDown.add(function () {
            g.game.raiseEvent(new g.MessageEvent({
              name: "start"
            }));
          }); //キーイベントを受け取る

          scene.onMessage.add(function (msg) {
            // 関係ないイベントは無視して抜ける
            if (!msg.data) return; //参加ボタンを押したとき

            if (msg.data.name == "join") {
              playerIds.push(msg.player);
              labelCount.text = playerIds.length + "人";
              labelCount.invalidate();
            } //開始ボタンを押したとき


            if (msg.data.name == "start") {
              _this.start(playerIds);
            }
          });

          _this.onUpdate.add(function () {
            //放送者の場合、開始ボタンを表示
            if (!buttonStart.visible()) {
              if (g.game.vars.gameMasterId === g.game.selfId) {
                buttonStart.show();
              }
            }
          });

          return _this;
        }

        return Title;
      }(g.E);

      exports.Title = Title;
    }, {
      "@akashic-extension/resolve-player-info": 10
    }],
    14: [function (require, module, exports) {
      var main_1 = require("./main");

      module.exports = function (originalParam) {
        var param = {};
        Object.keys(originalParam).forEach(function (key) {
          param[key] = originalParam[key];
        }); // セッションパラメーター

        param.sessionParameter = {}; // コンテンツが動作している環境がゲームアツマール上かどうか

        param.isAtsumaru = typeof window !== "undefined" && typeof window.RPGAtsumaru !== "undefined"; // 乱数生成器

        param.random = g.game.random;
        var limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数

        var scene = new g.Scene({
          game: g.game,
          name: "_bootstrap"
        }); // セッションパラメーターを受け取ってゲームを開始します

        scene.onMessage.add(function (msg) {
          if (msg.data && msg.data.type === "start" && msg.data.parameters) {
            param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加

            if (msg.data.parameters.randomSeed != null) {
              param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
            }

            g.game.popScene();
            (0, main_1.main)(param);
          }
        });
        scene.onLoad.add(function () {
          var currentTickCount = 0;
          scene.onUpdate.add(function () {
            currentTickCount++; // 待ち時間を超えた場合はゲームを開始します

            if (currentTickCount > limitTickToWait) {
              g.game.popScene();
              (0, main_1.main)(param);
            }
          });
        });
        g.game.pushScene(scene);
      };
    }, {
      "./main": 15
    }],
    15: [function (require, module, exports) {
      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.main = void 0;

      var Title_1 = require("./Title");

      var MainGame_1 = require("./MainGame");

      function main(param) {
        var scene = new g.Scene({
          game: g.game,
          // このシーンで利用するアセットのIDを列挙し、シーンに通知します
          assetIds: ["kaeru", "title", "start", "time", "number", "glyph", "bgm", "se_move", "se_start", "se_timeup"]
        }); // 放送者を区別する

        g.game.vars.gameMasterId = null;
        g.game.onJoin.addOnce(function (e) {
          g.game.vars.gameMasterId = e.player.id;
        }); // 市場コンテンツのランキングモードでは、g.game.vars.gameState.score の値をスコアとして扱います

        g.game.vars.gameState = {
          score: 0
        };
        scene.onLoad.add(function () {
          // 背景
          var bg = new g.FilledRect({
            scene: scene,
            width: g.game.width,
            height: g.game.height,
            cssColor: "black",
            opacity: 0.5,
            parent: scene
          });
          var title = new Title_1.Title();

          title.start = function (playerIds) {
            title.remove();
            var mainGame = new MainGame_1.MainGame();
            scene.append(mainGame);
            mainGame.init(playerIds);
          };

          var bgm = scene.asset.getAudioById("bgm").play();
          bgm.changeVolume(0.2);
        });
        g.game.pushScene(scene);
      }

      exports.main = main;
    }, {
      "./MainGame": 11,
      "./Title": 13
    }]
  }, {}, [14])(14);
});