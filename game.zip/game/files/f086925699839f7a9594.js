function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      var main_1 = require("./main");

      module.exports = function (originalParam) {
        var param = {};
        Object.keys(originalParam).forEach(function (key) {
          param[key] = originalParam[key];
        }); // セッションパラメーター

        param.sessionParameter = {}; // コンテンツが動作している環境がゲームアツマール上かどうか

        param.isAtsumaru = typeof window !== "undefined" && typeof window.RPGAtsumaru !== "undefined"; // 乱数生成器

        param.random = g.game.random;
        var limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数

        var scene = new g.Scene({
          game: g.game,
          name: "_bootstrap"
        }); // セッションパラメーターを受け取ってゲームを開始します

        scene.onMessage.add(function (msg) {
          if (msg.data && msg.data.type === "start" && msg.data.parameters) {
            param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加

            if (msg.data.parameters.randomSeed != null) {
              param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
            }

            g.game.popScene();
            (0, main_1.main)(param);
          }
        });
        scene.onLoad.add(function () {
          var currentTickCount = 0;
          scene.onUpdate.add(function () {
            currentTickCount++; // 待ち時間を超えた場合はゲームを開始します

            if (currentTickCount > limitTickToWait) {
              g.game.popScene();
              (0, main_1.main)(param);
            }
          });
        });
        g.game.pushScene(scene);
      };
    }, {
      "./main": 2
    }],
    2: [function (require, module, exports) {
      var __extends = this && this.__extends || function () {
        var _extendStatics = function extendStatics(d, b) {
          _extendStatics = Object.setPrototypeOf || {
            __proto__: []
          } instanceof Array && function (d, b) {
            d.__proto__ = b;
          } || function (d, b) {
            for (var p in b) {
              if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
            }
          };

          return _extendStatics(d, b);
        };

        return function (d, b) {
          if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");

          _extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.main = void 0;

      function main(param) {
        var scene = new g.Scene({
          game: g.game,
          // このシーンで利用するアセットのIDを列挙し、シーンに通知します
          assetIds: ["player", "shot", "se"]
        });
        var time = 60; // 制限時間

        if (param.sessionParameter.totalTimeLimit) {
          time = param.sessionParameter.totalTimeLimit; // セッションパラメータで制限時間が指定されたらその値を使用します
        } // 市場コンテンツのランキングモードでは、g.game.vars.gameState.score の値をスコアとして扱います


        g.game.vars.gameState = {
          score: 0
        };
        scene.onLoad.add(function () {
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: "sans-serif",
            size: 50
          });
          var label = new g.Label({
            scene: scene,
            font: font,
            text: "Hello World!",
            fontSize: 50,
            textColor: "black",
            parent: scene,
            local: true
          });
          var players = {};
          var button = new g.FilledRect({
            scene: scene,
            x: g.game.width - 60,
            y: 10,
            width: 50,
            height: 50,
            cssColor: "yellow",
            parent: scene,
            touchable: true,
            local: true
          });
          button.onPointDown.add(function (e) {
            button.hide();
            focus(); //フォーカス

            g.game.raiseEvent(new g.MessageEvent({
              playerId: e.player.id
            })); //キーボードイベント

            document.addEventListener("keydown", function (ev) {
              ev.preventDefault();
              label.text = ev.key;
              label.invalidate();
              g.game.raiseEvent(new g.MessageEvent({
                isPush: true,
                key: ev.key,
                pId: e.player.id
              }));
            });
            document.addEventListener("keyup", function (ev) {
              ev.preventDefault();
              g.game.raiseEvent(new g.MessageEvent({
                isPush: false,
                key: ev.key,
                pId: e.player.id
              }));
            });
          }); //キーイベントを受け取る

          scene.onMessage.add(function (msg) {
            // 関係ないイベントは無視して抜ける
            if (!msg.data) return;
            var ev = msg.data;

            if (ev.playerId) {
              var player = new Player({
                scene: scene,
                x: (g.game.width - 50) / 2,
                y: (g.game.height - 50) / 2,
                width: 50,
                height: 50,
                cssColor: "blue",
                parent: scene
              });
              players[ev.playerId] = player;
            }

            if (ev.key) {
              var player = players[ev.pId];

              if (ev.isPush) {
                if (ev.key == "a" || ev.key == "A") {
                  player.cssColor = player.cssColor == "green" ? "blue" : "green";
                }

                if (ev.key == "ArrowUp") {
                  player.moveY = -5;
                }

                if (ev.key == "ArrowDown") {
                  player.moveY = 5;
                }

                if (ev.key == "ArrowRight") {
                  player.moveX = 5;
                }

                if (ev.key == "ArrowLeft") {
                  player.moveX = -5;
                }
              } else {
                if (ev.key == "ArrowUp") {
                  player.moveY = 0;
                }

                if (ev.key == "ArrowDown") {
                  player.moveY = 0;
                }

                if (ev.key == "ArrowRight") {
                  player.moveX = 0;
                }

                if (ev.key == "ArrowLeft") {
                  player.moveX = 0;
                }
              }
            }
          });
          scene.onUpdate.add(function () {
            for (var key in players) {
              var player = players[key];
              player.x += player.moveX;
              player.y += player.moveY;
              player.modified();
            }
          });
        });
        g.game.pushScene(scene);
      }

      exports.main = main; //プレイヤークラス

      var Player =
      /** @class */
      function (_super) {
        __extends(Player, _super);

        function Player() {
          var _this = _super !== null && _super.apply(this, arguments) || this;

          _this.moveX = 0;
          _this.moveY = 0;
          return _this;
        }

        return Player;
      }(g.FilledRect);
    }, {}]
  }, {}, [1])(1);
});